"""
Unit tests for Milestone 3: Statistical anomaly detection engine.
Validates Median/MAD math, zero-MAD fallback hierarchy, insufficient history guard,
boundary severity conditions, non-finite safety, time-matching query, and persistence.
"""

from datetime import datetime, timezone
import math
from pathlib import Path
import sqlite3
import statistics
import sys
import tempfile
import unittest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from database import get_connection, get_db, init_db, seed_historical_baseline
from detector import (
    classify_severity,
    compute_robust_scale,
    detect_and_record_anomaly,
    evaluate_observation,
    get_historical_observations,
    scan_hour_anomalies,
)


class TestStatisticalDetectorCoreMath(unittest.TestCase):
    """Tests the mathematical calculations, fallback hierarchy, and boundary classifications."""

    def test_insufficient_history_returns_cold_start_status(self):
        """Verifies that fewer than 14 observations returns INSUFFICIENT_HISTORY and no anomaly."""
        short_history = [4, 5, 3, 6, 4]  # Only 5 observations
        res = evaluate_observation(
            current_count=15,
            history=short_history,
            time_bucket="2026-10-23T14:00:00Z",
            disease="Dengue",
            region="Central Metro",
            min_history=14,
        )

        self.assertEqual(res["status"], "INSUFFICIENT_HISTORY")
        self.assertFalse(res["is_anomaly"])
        self.assertEqual(res["severity"], "NORMAL")
        self.assertIsNone(res["score"])
        self.assertIn("Insufficient historical observations", res["rationale"])

    def test_all_zero_history_zero_mad_fallback(self):
        """
        Verifies that an all-zero history [0]*14 triggers the scale floor (max(2.0, 0.25*median) = 2.0)
        and prevents division by zero or infinite Z-scores.
        """
        zero_history = [0] * 14
        median_val = statistics.median(zero_history)
        scale, method = compute_robust_scale([float(x) for x in zero_history], median_val)

        self.assertEqual(method, "ZERO_VARIATION_FLOOR")
        self.assertEqual(scale, 2.0)

        # 1. Minor count of 1 -> Z = 1 / 2.0 = 0.5 -> NORMAL
        res_normal = evaluate_observation(
            current_count=1,
            history=zero_history,
            time_bucket="2026-10-23T14:00:00Z",
            disease="Dengue",
            region="Central Metro",
        )
        self.assertEqual(res_normal["score"], 0.5)
        self.assertFalse(res_normal["is_anomaly"])
        self.assertEqual(res_normal["severity"], "NORMAL")

        # 2. Surge to 8 cases -> Z = 8 / 2.0 = 4.0 -> MEDIUM (since count < 10)
        res_med = evaluate_observation(
            current_count=8,
            history=zero_history,
            time_bucket="2026-10-23T14:00:00Z",
            disease="Dengue",
            region="Central Metro",
        )
        self.assertEqual(res_med["score"], 4.0)
        self.assertTrue(res_med["is_anomaly"])
        self.assertEqual(res_med["severity"], "MEDIUM")

        # 3. Urgent surge to 14 cases -> Z = 14 / 2.0 = 7.0 -> HIGH (since count >= 10 and Z >= 5.0)
        res_high = evaluate_observation(
            current_count=14,
            history=zero_history,
            time_bucket="2026-10-23T14:00:00Z",
            disease="Dengue",
            region="Central Metro",
        )
        self.assertEqual(res_high["score"], 7.0)
        self.assertTrue(res_high["is_anomaly"])
        self.assertEqual(res_high["severity"], "HIGH")

    def test_constant_nonzero_history_zero_mad_fallback(self):
        """
        Verifies that constant nonzero history [4]*14 uses scale floor max(2.0, 0.25*4.0) = 2.0.
        """
        const_history = [4] * 14
        median_val = statistics.median(const_history)
        scale, method = compute_robust_scale([float(x) for x in const_history], median_val)

        self.assertEqual(method, "ZERO_VARIATION_FLOOR")
        self.assertEqual(scale, 2.0)

        # Baseline count (4) -> Z = (4 - 4) / 2.0 = 0.0 -> NORMAL
        res_base = evaluate_observation(
            current_count=4,
            history=const_history,
            time_bucket="2026-10-23T14:00:00Z",
            disease="Dengue",
            region="Central Metro",
        )
        self.assertEqual(res_base["score"], 0.0)
        self.assertEqual(res_base["severity"], "NORMAL")

        # Count 16 -> Z = (16 - 4) / 2.0 = 6.0 -> HIGH (count 16 >= 10)
        res_high = evaluate_observation(
            current_count=16,
            history=const_history,
            time_bucket="2026-10-23T14:00:00Z",
            disease="Dengue",
            region="Central Metro",
        )
        self.assertEqual(res_high["score"], 6.0)
        self.assertEqual(res_high["severity"], "HIGH")

    def test_nonzero_mad_scale(self):
        """Verifies standard normal-consistent MAD scale (1.4826 * MAD) when MAD > 0."""
        history = [2, 3, 3, 4, 4, 4, 4, 4, 5, 5, 5, 6, 7, 8]
        median_val = statistics.median(history)  # 4.0
        abs_devs = [abs(x - median_val) for x in history]
        raw_mad = statistics.median(abs_devs)  # 1.0

        scale, method = compute_robust_scale([float(x) for x in history], median_val)
        self.assertEqual(method, "MAD")
        self.assertAlmostEqual(scale, 1.4826 * raw_mad, places=4)

    def test_sample_std_fallback_when_mad_is_zero_but_std_nonzero(self):
        """
        Verifies Tier 2 fallback: when >50% of history is identical, MAD == 0,
        but sample standard deviation > 0.
        """
        # 10 fours and 4 fives: Median is 4. Nine deviations are 0, five deviations are 1.
        # Median of deviations is 0 -> MAD = 0.
        history = [4] * 10 + [5] * 4
        median_val = statistics.median(history)
        scale, method = compute_robust_scale([float(x) for x in history], median_val)

        self.assertEqual(method, "SAMPLE_STD_FALLBACK")
        expected_std = statistics.stdev(history)
        self.assertAlmostEqual(scale, expected_std, places=4)

    def test_prototype_severity_threshold_boundaries(self):
        """Verifies exact severity classification boundaries and count >= 10 rule for High."""
        # 1. Normal boundary (< 2.5)
        sev, is_ano = classify_severity(2.49, current_count=15)
        self.assertEqual(sev, "NORMAL")
        self.assertFalse(is_ano)

        # 2. Low boundary [2.5, 3.5)
        sev, is_ano = classify_severity(2.50, current_count=15)
        self.assertEqual(sev, "LOW")
        self.assertTrue(is_ano)

        sev, is_ano = classify_severity(3.49, current_count=15)
        self.assertEqual(sev, "LOW")

        # 3. Medium boundary [3.5, 5.0)
        sev, is_ano = classify_severity(3.50, current_count=15)
        self.assertEqual(sev, "MEDIUM")
        self.assertTrue(is_ano)

        sev, is_ano = classify_severity(4.99, current_count=15)
        self.assertEqual(sev, "MEDIUM")

        # 4. High boundary (>= 5.0 and count >= 10)
        sev, is_ano = classify_severity(5.00, current_count=10)
        self.assertEqual(sev, "HIGH")
        self.assertTrue(is_ano)

        # 5. Capping rule: Score >= 5.0 but current_count < 10 -> Capped at MEDIUM
        sev, is_ano = classify_severity(5.50, current_count=8)
        self.assertEqual(sev, "MEDIUM", "Surges with count < 10 must be capped at MEDIUM to prevent small-number artifacts!")
        self.assertTrue(is_ano)

    def test_non_finite_values_safety(self):
        """Verifies that NaN and Inf scores never crash and default safely to NORMAL."""
        sev, is_ano = classify_severity(float("nan"), current_count=10)
        self.assertEqual(sev, "NORMAL")
        self.assertFalse(is_ano)

        sev, is_ano = classify_severity(float("inf"), current_count=10)
        self.assertEqual(sev, "NORMAL")
        self.assertFalse(is_ano)

    def test_known_injected_outbreak_surge_fixture(self):
        """
        Verifies that a known simulated outbreak surge produces the expected High anomaly.
        Fixture: 14 baseline days with median 4.0, scale 1.5. Injected surge = 22 cases.
        Z = (22 - 4.0) / 1.5 = 12.00 >= 5.0, count >= 10 -> HIGH
        """
        # Realistic diurnal Dengue counts at 14:00
        baseline_fixture = [3, 4, 4, 5, 3, 4, 5, 4, 4, 3, 5, 4, 4, 5]
        injected_cases = 22

        res = evaluate_observation(
            current_count=injected_cases,
            history=baseline_fixture,
            time_bucket="2026-10-23T14:00:00Z",
            disease="Dengue",
            region="Central Metro",
        )

        self.assertEqual(res["status"], "EVALUATED")
        self.assertTrue(res["is_anomaly"])
        self.assertEqual(res["severity"], "HIGH")
        self.assertGreaterEqual(res["score"], 5.0)
        self.assertEqual(res["observed_count"], 22)
        self.assertIn("exceeds 14-day median baseline", res["rationale"])
        self.assertIn("triggering a HIGH anomaly signal", res["rationale"])


class TestDetectorDatabaseIntegration(unittest.TestCase):
    """Tests SQLite historical query extraction and anomaly table persistence."""

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_detector_db.db"
        # Seed 14 days of history (2026-10-09 to 2026-10-22)
        seed_historical_baseline(self.db_path, seed=42, force=True)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_time_matched_historical_query(self):
        """
        Verifies that get_historical_observations extracts exactly 14 time-matched observations
        from preceding days at that exact same hour of day.
        """
        # Query for 2026-10-23 at 14:00 UTC
        eval_time = "2026-10-23T14:00:00Z"

        with get_db(self.db_path) as conn:
            history = get_historical_observations(
                conn, disease="Dengue", region="Central Metro", current_timestamp=eval_time, max_points=14
            )

        self.assertEqual(len(history), 14, "Should retrieve exactly 14 preceding baseline days for hour 14!")
        # Non-negative counts
        for count in history:
            self.assertGreaterEqual(count, 0)

    def test_detected_anomaly_persistence(self):
        """Verifies that detected anomalies (Z >= 2.5) are persisted into detected_anomalies."""
        eval_time = "2026-10-23T14:00:00Z"
        surge_count = 25  # Substantial surge above normal Dengue baseline (approx 4)

        with get_db(self.db_path) as conn:
            res = detect_and_record_anomaly(
                conn=conn,
                current_count=surge_count,
                time_bucket=eval_time,
                disease="Dengue",
                region="Central Metro",
                persist=True,
            )

            self.assertTrue(res["is_anomaly"])
            self.assertIn("anomaly_id", res)
            self.assertEqual(res["severity"], "HIGH")

            # Check detected_anomalies table in DB
            cur = conn.cursor()
            cur.execute("SELECT * FROM detected_anomalies WHERE anomaly_id = ?;", (res["anomaly_id"],))
            row = cur.fetchone()

            self.assertIsNotNone(row)
            self.assertEqual(row["observed_count"], 25)
            self.assertEqual(row["disease"], "Dengue")
            self.assertEqual(row["region"], "Central Metro")
            self.assertEqual(row["severity"], "HIGH")
            self.assertGreaterEqual(row["score"], 5.0)

    def test_normal_observation_is_not_persisted_to_anomalies(self):
        """Verifies that normal observations (Z < 2.5) are NOT inserted into detected_anomalies."""
        eval_time = "2026-10-23T14:00:00Z"
        normal_count = 4  # Normal Dengue count

        with get_db(self.db_path) as conn:
            res = detect_and_record_anomaly(
                conn=conn,
                current_count=normal_count,
                time_bucket=eval_time,
                disease="Dengue",
                region="Central Metro",
                persist=True,
            )

            self.assertFalse(res["is_anomaly"])
            self.assertEqual(res["severity"], "NORMAL")
            self.assertNotIn("anomaly_id", res)

            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) AS cnt FROM detected_anomalies;")
            self.assertEqual(cur.fetchone()["cnt"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
