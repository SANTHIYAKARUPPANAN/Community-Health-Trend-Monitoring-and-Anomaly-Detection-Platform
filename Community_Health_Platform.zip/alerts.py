"""
Alert Management and Local Mock Notification Module.
Handles alert creation from statistical anomalies, 60-minute duplicate suppression cooldown,
severity escalation, valid lifecycle state transitions, normalization checking,
immutable audit logging, and local HTML mock-email briefs.
"""

from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import sqlite3
from typing import Any, Dict, List, Optional, Tuple
import uuid

from config import (
    ALERT_COOLDOWN_MINUTES,
    MOCK_EMAIL_DIR,
    SYNTHETIC_DATA_DISCLAIMER,
)
from detector import evaluate_observation, get_historical_observations

# -------------------------------------------------------------------------
# Lifecycle Transition Rules
# -------------------------------------------------------------------------
VALID_STATUSES = {"PENDING", "ACKNOWLEDGED", "UNDER_INVESTIGATION", "RESOLVED"}

ALLOWED_TRANSITIONS = {
    "PENDING": {"ACKNOWLEDGED", "UNDER_INVESTIGATION"},
    "ACKNOWLEDGED": {"UNDER_INVESTIGATION", "RESOLVED"},
    "UNDER_INVESTIGATION": {"RESOLVED", "UNDER_INVESTIGATION"},  # Notes can be appended
    "RESOLVED": set(),  # Terminal state
}


# -------------------------------------------------------------------------
# HTML Mock Email Generator
# -------------------------------------------------------------------------
def generate_mock_email_html(alert: Dict[str, Any], anomaly: Dict[str, Any]) -> str:
    """
    Constructs a professional HTML alert brief.
    Includes a mandatory, prominent statement that the message was NOT delivered externally.
    """
    severity_colors = {
        "HIGH": "#DC2626",  # Red
        "MEDIUM": "#D97706",  # Amber
        "LOW": "#2563EB",  # Blue
    }
    badge_color = severity_colors.get(alert["severity"], "#4B5563")

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Surveillance Alert Brief: {alert['alert_id']}</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; line-height: 1.5; color: #1E293B; background: #F8FAFC; margin: 0; padding: 24px; }}
  .container {{ max-width: 680px; margin: 0 auto; background: #FFFFFF; border-radius: 8px; border: 1px solid #E2E8F0; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }}
  .disclaimer-banner {{ background: #FEF3C7; border-bottom: 2px solid #F59E0B; color: #92400E; padding: 12px 20px; font-size: 13px; font-weight: 600; text-align: center; }}
  .header {{ padding: 24px 28px; border-bottom: 1px solid #E2E8F0; background: #0F172A; color: #FFFFFF; }}
  .header h1 {{ margin: 0 0 6px 0; font-size: 20px; font-weight: 700; }}
  .header p {{ margin: 0; font-size: 13px; color: #94A3B8; }}
  .badge {{ display: inline-block; padding: 4px 10px; border-radius: 4px; font-size: 12px; font-weight: 700; color: #FFFFFF; background: {badge_color}; }}
  .content {{ padding: 24px 28px; }}
  .metrics-table {{ width: 100%; border-collapse: collapse; margin: 16px 0 24px 0; }}
  .metrics-table th, .metrics-table td {{ padding: 10px 14px; text-align: left; border-bottom: 1px solid #E2E8F0; font-size: 14px; }}
  .metrics-table th {{ background: #F8FAFC; color: #64748B; font-weight: 600; width: 40%; }}
  .evidence-box {{ background: #F1F5F9; border-left: 4px solid {badge_color}; padding: 14px 18px; border-radius: 0 6px 6px 0; margin-bottom: 24px; }}
  .evidence-box p {{ margin: 0; font-size: 14px; color: #334155; font-style: italic; }}
  .actions-list {{ background: #EFF6FF; border: 1px solid #BFDBFE; border-radius: 6px; padding: 16px 20px; margin-bottom: 20px; }}
  .actions-list h3 {{ margin: 0 0 10px 0; font-size: 14px; color: #1E40AF; }}
  .actions-list ol {{ margin: 0; padding-left: 20px; font-size: 13px; color: #1E3A8A; }}
  .actions-list li {{ margin-bottom: 6px; }}
  .footer {{ padding: 16px 28px; background: #F8FAFC; border-top: 1px solid #E2E8F0; font-size: 11px; color: #64748B; text-align: center; }}
</style>
</head>
<body>
<div class="container">
  <div class="disclaimer-banner">
    ⚠️ LOCAL MOCK NOTIFICATION &mdash; Stored locally for academic demonstration. NOT delivered to external networks.
  </div>
  <div class="header">
    <h1>District Health Surveillance & Early Warning Brief</h1>
    <p>Automated Decision-Support System &bull; University Mini-Project Evaluation</p>
  </div>
  <div class="content">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
      <div>
        <span style="font-size: 13px; color: #64748B;">Tracking Identifier:</span>
        <strong style="font-size: 15px; margin-left: 6px;">{alert['alert_id']}</strong>
      </div>
      <div>
        <span class="badge">{alert['severity']} PRIORITY</span>
      </div>
    </div>

    <table class="metrics-table">
      <tr>
        <th>Indicator Disease</th>
        <td><strong>{alert['disease']}</strong></td>
      </tr>
      <tr>
        <th>Surveillance District</th>
        <td>{alert['region']}</td>
      </tr>
      <tr>
        <th>Observed Case Count</th>
        <td><strong>{anomaly.get('observed_count', 'N/A')} cases</strong> (in 1-hour window)</td>
      </tr>
      <tr>
        <th>14-Day Median Baseline</th>
        <td>{anomaly.get('baseline_median', 'N/A')} cases</td>
      </tr>
      <tr>
        <th>Robust Deviation Score</th>
        <td><strong>Z = {anomaly.get('score', 'N/A')}</strong> (Scale = {anomaly.get('dispersion_scale', 'N/A')})</td>
      </tr>
      <tr>
        <th>Detection Time</th>
        <td>{anomaly.get('time_bucket', 'N/A')}</td>
      </tr>
      <tr>
        <th>Initial Status</th>
        <td><code>{alert['status']}</code></td>
      </tr>
    </table>

    <div class="evidence-box">
      <p>&ldquo;{anomaly.get('rationale', 'Statistical deviation detected across baseline series.')}&rdquo;</p>
    </div>

    <div class="actions-list">
      <h3>Recommended Officer Response Actions:</h3>
      <ol>
        <li>Access the Community Health Surveillance Dashboard and navigate to the <strong>Alert Investigation</strong> section.</li>
        <li>Inspect the Plotly epidemiological trend curves to review time-matched baseline bounds.</li>
        <li>Update alert status to <strong>ACKNOWLEDGED</strong> and record investigative field notes.</li>
        <li>Contact local district clinic representatives if vector control or field triage is warranted.</li>
      </ol>
    </div>
  </div>
  <div class="footer">
    {SYNTHETIC_DATA_DISCLAIMER}<br/>
    Generated by Antigravity Community Health Surveillance Prototype &bull; File saved locally for testing.
  </div>
</div>
</body>
</html>"""
    return html


# -------------------------------------------------------------------------
# Local Mock Notification Dispatcher
# -------------------------------------------------------------------------
def dispatch_local_mock_notification(
    conn: sqlite3.Connection,
    alert: Dict[str, Any],
    anomaly: Dict[str, Any],
    recipient: str = "district-officer@surveillance.local",
    output_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    """
    Renders and saves a mock HTML email to the local filesystem.
    Records delivery status (MOCK_SAVED or MOCK_FAILED) in mock_notifications.
    Never attempts external network delivery.
    """
    target_dir = Path(output_dir) if output_dir else MOCK_EMAIL_DIR
    time_str = anomaly.get("time_bucket", "now").replace(":", "").replace("-", "")
    filename = f"{alert['alert_id']}_{alert['disease']}_{alert['region']}_{time_str}.html".replace(" ", "_")
    file_path = target_dir / filename
    html_content = generate_mock_email_html(alert, anomaly)

    now_str = datetime.now(timezone.utc).isoformat()

    try:
        target_dir.mkdir(parents=True, exist_ok=True)
        file_path.write_text(html_content, encoding="utf-8")
        status = "MOCK_SAVED"
        error_msg = None
    except Exception as e:
        status = "MOCK_FAILED"
        error_msg = str(e)

    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT INTO mock_notifications (alert_id, recipient, status, file_path, sent_at)
        VALUES (?, ?, ?, ?, ?);
        """,
        (alert["alert_id"], recipient, status, str(file_path), now_str),
    )
    notif_id = cursor.lastrowid

    # Append notification event to audit log
    action_note = f"Mock email brief saved to {file_path.name}" if status == "MOCK_SAVED" else f"Mock email write failed: {error_msg}"
    cursor.execute(
        """
        INSERT INTO alert_audit_logs (alert_id, action, previous_status, new_status, officer_notes, timestamp)
        VALUES (?, ?, ?, ?, ?, ?);
        """,
        (alert["alert_id"], status, alert["status"], alert["status"], action_note, now_str),
    )

    return {
        "notification_id": notif_id,
        "status": status,
        "file_path": str(file_path),
        "error_message": error_msg,
    }


# -------------------------------------------------------------------------
# Alert Lifecycle & Cooldown Processor
# -------------------------------------------------------------------------
def process_anomaly_for_alert(
    conn: sqlite3.Connection,
    anomaly: Dict[str, Any],
    cooldown_minutes: int = ALERT_COOLDOWN_MINUTES,
    output_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    """
    Evaluates an anomaly result, creates alerts, manages cooldown, and dispatches mock emails.

    Rules:
      1. LOW severity anomalies are watchlist-only: stored in detected_anomalies, no alert created.
      2. If an active alert exists within the 60-minute cooldown window:
         - Same or lower severity -> Suppress duplicate; record COOLDOWN_SUPPRESSED audit event.
         - Worsening severity (MEDIUM -> HIGH) -> Update existing alert, record SEVERITY_ESCALATED,
           and dispatch an escalated mock email brief.
      3. Otherwise -> Create new PENDING alert, record ALERT_CREATED audit event, and dispatch mock email.
    """
    severity = anomaly.get("severity", "NORMAL")
    if severity not in ("MEDIUM", "HIGH"):
        return {
            "status": "WATCHLIST_ONLY",
            "alert_id": None,
            "reason": f"{severity} severity anomaly recorded in detected_anomalies as watchlist signal; no alert created.",
        }

    disease = anomaly["disease"]
    region = anomaly["region"]
    obs_time_str = anomaly["time_bucket"]
    clean_obs_time = obs_time_str.replace("Z", "+00:00")
    obs_dt = datetime.fromisoformat(clean_obs_time)
    now_str = datetime.now(timezone.utc).isoformat()

    cursor = conn.cursor()

    # Query for existing non-resolved alert on (disease, region)
    cursor.execute(
        """
        SELECT alert_id, disease, region, severity, status, created_at, updated_at
        FROM alerts
        WHERE disease = ? AND region = ?
          AND status IN ('PENDING', 'ACKNOWLEDGED', 'UNDER_INVESTIGATION')
        ORDER BY updated_at DESC
        LIMIT 1;
        """,
        (disease, region),
    )
    active_alert = cursor.fetchone()

    if active_alert:
        active_dict = dict(active_alert)
        last_dt_str = active_dict["updated_at"].replace("Z", "+00:00")
        try:
            last_dt = datetime.fromisoformat(last_dt_str)
            time_diff_min = abs((obs_dt - last_dt).total_seconds()) / 60.0
        except Exception:
            time_diff_min = 999.0

        if time_diff_min <= cooldown_minutes:
            # Within 60-minute cooldown window
            current_alert_sev = active_dict["severity"]

            # Check if anomaly worsened (MEDIUM -> HIGH)
            if current_alert_sev == "MEDIUM" and severity == "HIGH":
                cursor.execute(
                    """
                    UPDATE alerts
                    SET severity = 'HIGH', updated_at = ?
                    WHERE alert_id = ?;
                    """,
                    (obs_time_str, active_dict["alert_id"]),
                )
                escalation_note = (
                    f"Surge escalated from MEDIUM to HIGH (Z={anomaly['score']:.2f}, cases={anomaly['observed_count']}). "
                    f"Generated escalated mock notification."
                )
                cursor.execute(
                    """
                    INSERT INTO alert_audit_logs (alert_id, action, previous_status, new_status, officer_notes, timestamp)
                    VALUES (?, 'SEVERITY_ESCALATED', ?, ?, ?, ?);
                    """,
                    (active_dict["alert_id"], active_dict["status"], active_dict["status"], escalation_note, now_str),
                )

                # Dispatch escalated mock email
                active_dict["severity"] = "HIGH"
                notif_res = dispatch_local_mock_notification(
                    conn, active_dict, anomaly, output_dir=output_dir
                )

                return {
                    "status": "SEVERITY_ESCALATED",
                    "alert_id": active_dict["alert_id"],
                    "severity": "HIGH",
                    "notification": notif_res,
                }
            else:
                # Same or lower severity within cooldown -> Suppress duplicate
                suppress_note = (
                    f"Anomaly continues within {cooldown_minutes}-min cooldown window "
                    f"(Z={anomaly['score']:.2f}, {severity}). Duplicate alert and notification suppressed."
                )
                cursor.execute(
                    """
                    INSERT INTO alert_audit_logs (alert_id, action, previous_status, new_status, officer_notes, timestamp)
                    VALUES (?, 'COOLDOWN_SUPPRESSED', ?, ?, ?, ?);
                    """,
                    (active_dict["alert_id"], active_dict["status"], active_dict["status"], suppress_note, now_str),
                )
                return {
                    "status": "COOLDOWN_SUPPRESSED",
                    "alert_id": active_dict["alert_id"],
                    "reason": suppress_note,
                }

    # No active alert within cooldown -> Create fresh alert
    alert_id = f"ALT-{datetime.now(timezone.utc).strftime('%Y%m%d')}-{uuid.uuid4().hex[:6].upper()}"
    anomaly_id = anomaly.get("anomaly_id")

    # Ensure foreign key constraint is satisfied
    if anomaly_id:
        cursor.execute("SELECT anomaly_id FROM detected_anomalies WHERE anomaly_id = ?;", (anomaly_id,))
        if not cursor.fetchone():
            anomaly_id = None

    if not anomaly_id:
        # Persist into detected_anomalies to satisfy foreign key
        cursor.execute(
            """
            INSERT INTO detected_anomalies (
                time_bucket, disease, region, observed_count,
                baseline_median, dispersion_scale, score, severity,
                rationale, detected_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """,
            (
                anomaly["time_bucket"],
                anomaly["disease"],
                anomaly["region"],
                anomaly.get("observed_count", 0),
                anomaly.get("baseline_median", 0.0),
                anomaly.get("dispersion_scale", 1.0),
                anomaly.get("score", 0.0),
                anomaly.get("severity", severity),
                anomaly.get("rationale", "Anomaly detected"),
                now_str,
            ),
        )
        anomaly_id = cursor.lastrowid
        anomaly["anomaly_id"] = anomaly_id

    cursor.execute(
        """
        INSERT INTO alerts (alert_id, anomaly_id, disease, region, severity, status, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, 'PENDING', ?, ?);
        """,
        (alert_id, anomaly_id, disease, region, severity, obs_time_str, obs_time_str),
    )

    created_note = (
        f"Alert created from {severity} anomaly (Z={anomaly['score']:.2f}, cases={anomaly['observed_count']}). "
        f"{anomaly['rationale']}"
    )
    cursor.execute(
        """
        INSERT INTO alert_audit_logs (alert_id, action, previous_status, new_status, officer_notes, timestamp)
        VALUES (?, 'ALERT_CREATED', NULL, 'PENDING', ?, ?);
        """,
        (alert_id, created_note, now_str),
    )

    alert_obj = {
        "alert_id": alert_id,
        "anomaly_id": anomaly_id,
        "disease": disease,
        "region": region,
        "severity": severity,
        "status": "PENDING",
        "created_at": obs_time_str,
        "updated_at": obs_time_str,
    }

    # Dispatch initial mock notification
    notif_res = dispatch_local_mock_notification(conn, alert_obj, anomaly, output_dir=output_dir)

    return {
        "status": "ALERT_CREATED",
        "alert_id": alert_id,
        "severity": severity,
        "notification": notif_res,
    }


# -------------------------------------------------------------------------
# Officer Lifecycle Status Transition
# -------------------------------------------------------------------------
def update_alert_status(
    conn: sqlite3.Connection,
    alert_id: str,
    new_status: str,
    officer_notes: str,
    officer_name: str = "District Officer",
) -> Dict[str, Any]:
    """
    Enforces valid alert state machine transitions and records immutable audit history.

    Valid transitions:
      PENDING -> ACKNOWLEDGED, UNDER_INVESTIGATION
      ACKNOWLEDGED -> UNDER_INVESTIGATION, RESOLVED
      UNDER_INVESTIGATION -> RESOLVED, UNDER_INVESTIGATION (Notes append)
      RESOLVED -> None (Terminal)
    """
    if new_status not in VALID_STATUSES:
        raise ValueError(f"Invalid alert status '{new_status}'. Allowed: {sorted(VALID_STATUSES)}")

    cursor = conn.cursor()
    cursor.execute(
        "SELECT alert_id, status, severity, disease, region FROM alerts WHERE alert_id = ?;",
        (alert_id,),
    )
    row = cursor.fetchone()
    if not row:
        raise ValueError(f"Alert '{alert_id}' not found.")

    current_status = row["status"]
    allowed = ALLOWED_TRANSITIONS.get(current_status, set())

    if new_status not in allowed:
        raise ValueError(
            f"Invalid status transition from '{current_status}' to '{new_status}'. "
            f"Allowed next states: {sorted(allowed) if allowed else 'None (Terminal state)'}"
        )

    now_str = datetime.now(timezone.utc).isoformat()
    cursor.execute(
        """
        UPDATE alerts
        SET status = ?, updated_at = ?
        WHERE alert_id = ?;
        """,
        (new_status, now_str, alert_id),
    )

    action_name = f"OFFICER_{new_status}"
    full_notes = f"[{officer_name}] {officer_notes.strip()}" if officer_notes.strip() else f"[{officer_name}] Status updated to {new_status}"

    cursor.execute(
        """
        INSERT INTO alert_audit_logs (alert_id, action, previous_status, new_status, officer_notes, timestamp)
        VALUES (?, ?, ?, ?, ?, ?);
        """,
        (alert_id, action_name, current_status, new_status, full_notes, now_str),
    )

    return {
        "alert_id": alert_id,
        "previous_status": current_status,
        "new_status": new_status,
        "officer": officer_name,
        "notes": full_notes,
        "updated_at": now_str,
    }


# -------------------------------------------------------------------------
# Normalization / Recovery Detection (Human-in-the-Loop)
# -------------------------------------------------------------------------
def check_alert_recovery(
    conn: sqlite3.Connection,
    disease: str,
    region: str,
    current_timestamp: str,
    consecutive_hours: int = 3,
) -> Dict[str, Any]:
    """
    Evaluates whether the last consecutive_hours (default 3) hourly observations
    for (disease, region) have normalized below the 2.5 deviation threshold.

    Public Health Governance Note:
      Recovery detection displays a normalization indicator to assist decision-making,
      but does NOT automatically resolve or close an alert. Closure remains an
      explicit officer action with documented resolution notes.
    """
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT time_bucket, total_cases
        FROM hourly_aggregates
        WHERE disease = ? AND region = ?
          AND time_bucket <= ?
        ORDER BY time_bucket DESC
        LIMIT ?;
        """,
        (disease, region, current_timestamp, consecutive_hours),
    )
    rows = cursor.fetchall()

    if len(rows) < consecutive_hours:
        return {
            "is_recovered": False,
            "consecutive_normal_hours": len(rows),
            "explanation": f"Insufficient recent observations ({len(rows)}/{consecutive_hours} hours available).",
        }

    normal_count = 0
    eval_details = []

    for row in rows:
        hist = get_historical_observations(conn, disease, region, row["time_bucket"], max_points=14)
        ev = evaluate_observation(
            current_count=row["total_cases"],
            history=hist,
            time_bucket=row["time_bucket"],
            disease=disease,
            region=region,
        )
        eval_details.append(ev)
        if not ev["is_anomaly"] and (ev["score"] is None or ev["score"] < 2.5):
            normal_count += 1

    is_recovered = (normal_count == consecutive_hours)
    if is_recovered:
        explanation = (
            f"Case counts have returned to normal baseline variance (Z < 2.5) for "
            f"{consecutive_hours} consecutive hours. Alert ready for officer review and resolution."
        )
    else:
        explanation = (
            f"Surveillance active: {consecutive_hours - normal_count} of last {consecutive_hours} "
            f"hours showed elevated counts."
        )

    return {
        "is_recovered": is_recovered,
        "consecutive_normal_hours": normal_count,
        "required_hours": consecutive_hours,
        "explanation": explanation,
        "evaluations": eval_details,
    }


def get_alert_history(conn: sqlite3.Connection, alert_id: str) -> List[Dict[str, Any]]:
    """
    Retrieves the complete immutable audit trail for a specific alert.
    """
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT audit_id, alert_id, action, previous_status, new_status, officer_notes, timestamp
        FROM alert_audit_logs
        WHERE alert_id = ?
        ORDER BY audit_id ASC;
        """,
        (alert_id,),
    )
    return [dict(row) for row in cursor.fetchall()]
