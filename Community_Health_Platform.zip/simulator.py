"""
Simulator Module for Community Health Trend Monitoring & Anomaly Detection Platform.
Provides deterministic generation of synthetic incoming reports, supplementary reports,
duplicate re-transmissions, and synchronous simulation-step progression.
"""

from datetime import datetime, timedelta, timezone
import math
from pathlib import Path
import random
import sqlite3
from typing import Any, Dict, List, Optional
import uuid

from config import (
    BASELINE_START_TIME,
    DB_PATH,
    DISEASE_NAMES,
    DISEASES,
    DISTRICT_FACILITIES,
    DISTRICTS,
    RANDOM_SEED,
)
from database import _sample_poisson, get_connection, get_db
from pipeline import ingest_batch


def generate_single_report(
    timestamp: datetime,
    region: str,
    disease: str,
    case_count: Optional[int] = None,
    client_submission_id: Optional[str] = None,
    facility: Optional[str] = None,
    rng: Optional[random.Random] = None,
) -> Dict[str, Any]:
    """
    Constructs a valid synthetic health record adhering to platform schema.
    """
    resolved_facility = facility if facility else DISTRICT_FACILITIES.get(region, "General Clinic")
    sub_id = client_submission_id if client_submission_id else str(uuid.uuid4())
    rec_id = f"REC-{uuid.uuid4().hex[:12].upper()}"

    if case_count is None:
        local_rng = rng if rng is not None else random.Random()
        hour = timestamp.hour
        weekday = timestamp.weekday()
        weekday_weights = {0: 1.15, 1: 1.0, 2: 1.0, 3: 1.0, 4: 1.0, 5: 0.85, 6: 0.75}
        w_factor = weekday_weights.get(weekday, 1.0)

        meta = DISEASES.get(disease, {"base_lambda": 3.0, "peak_hour": 12})
        base_lambda = meta["base_lambda"]
        peak = meta["peak_hour"]

        dist = abs(hour - peak)
        dist = min(dist, 24 - dist)
        diurnal_factor = 0.45 + 0.85 * math.exp(-(dist**2) / 18.0)
        expected_lambda = base_lambda * diurnal_factor * w_factor
        cases = _sample_poisson(expected_lambda, local_rng)
    else:
        cases = case_count

    ts_str = timestamp.strftime("%Y-%m-%dT%H:00:00Z")

    return {
        "record_id": rec_id,
        "client_submission_id": sub_id,
        "timestamp": ts_str,
        "facility_id": resolved_facility,
        "region": region,
        "disease": disease,
        "case_count": cases,
        "is_synthetic": 1,
    }


def generate_duplicate_retransmission(original_record: Dict[str, Any]) -> Dict[str, Any]:
    """
    Creates an exact duplicate retransmission clone sharing the identical client_submission_id.
    Used to verify idempotent deduplication.
    """
    clone = dict(original_record)
    # A retransmission may have a new internal network packet id, but identical client_submission_id
    clone["record_id"] = f"REC-RETRY-{uuid.uuid4().hex[:8].upper()}"
    return clone


def generate_supplementary_report(
    original_record: Dict[str, Any], additional_cases: int
) -> Dict[str, Any]:
    """
    Generates a legitimate supplementary report for the same facility, hour, disease,
    and region, but with a unique client_submission_id.
    """
    return {
        "record_id": f"REC-SUPP-{uuid.uuid4().hex[:8].upper()}",
        "client_submission_id": str(uuid.uuid4()),
        "timestamp": original_record["timestamp"],
        "facility_id": original_record["facility_id"],
        "region": original_record["region"],
        "disease": original_record["disease"],
        "case_count": additional_cases,
        "is_synthetic": 1,
    }


def simulate_hour_tick(
    db_path: Optional[Path] = None,
    seed: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Synchronously simulates 1 hour of streaming surveillance reports.

    Progression:
      1. Inspects the latest timestamp in raw_records.
      2. Advances the simulation clock by exactly +1 hour.
      3. Generates 20 incoming reports (5 districts * 4 diseases).
      4. Ingests them atomically through the pipeline into SQLite.
      Single-process, safe, and thread-free.
    """
    rng = random.Random(seed) if seed is not None else random.Random()

    with get_db(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT MAX(timestamp) AS latest_ts FROM raw_records;")
        row = cursor.fetchone()
        latest_ts_str = row["latest_ts"] if row and row["latest_ts"] else None

        if latest_ts_str:
            clean_ts = latest_ts_str.replace("Z", "+00:00")
            current_dt = datetime.fromisoformat(clean_ts)
            tick_dt = current_dt + timedelta(hours=1)
        else:
            tick_dt = BASELINE_START_TIME

        # Generate 1 report for each district and disease
        batch_records = []
        for region, facility in DISTRICT_FACILITIES.items():
            for disease in DISEASE_NAMES:
                rec = generate_single_report(
                    timestamp=tick_dt,
                    region=region,
                    disease=disease,
                    facility=facility,
                    rng=rng,
                )
                batch_records.append(rec)

        # Ingest atomically using tick_dt as the valid reference clock
        ingest_summary = ingest_batch(conn, batch_records, reference_now=tick_dt)

    return {
        "status": "SUCCESS",
        "tick_time": tick_dt.strftime("%Y-%m-%dT%H:00:00Z"),
        "records_generated": len(batch_records),
        "ingested": ingest_summary["ingested"],
        "duplicate_rejected": ingest_summary["duplicate_rejected"],
        "quarantined": ingest_summary["quarantined"],
    }
