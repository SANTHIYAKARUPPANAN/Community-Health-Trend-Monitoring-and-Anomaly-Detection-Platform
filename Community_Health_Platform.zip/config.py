"""
Configuration Module for Community Health Trend Monitoring & Anomaly Detection Platform.
Provides deterministic simulation parameters, disease baselines, geographic districts,
database paths, and surveillance thresholds.
"""

from datetime import datetime, timezone
import os
from pathlib import Path

# Base Paths
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.getenv("SURVEILLANCE_DATA_DIR", BASE_DIR / "data"))
DB_PATH = Path(os.getenv("SURVEILLANCE_DB_PATH", DATA_DIR / "health_surveillance.db"))
MOCK_EMAIL_DIR = Path(os.getenv("MOCK_EMAIL_DIR", DATA_DIR / "mock_emails"))

# Ensure runtime directories exist
DATA_DIR.mkdir(parents=True, exist_ok=True)
MOCK_EMAIL_DIR.mkdir(parents=True, exist_ok=True)

# -------------------------------------------------------------------------
# Geographic Districts & Reporting Health Facilities
# -------------------------------------------------------------------------
DISTRICT_FACILITIES = {
    "Central Metro": "Central District Hospital",
    "North Valley": "North Community Clinic",
    "South Coast": "South Coast Health Center",
    "Eastern Highlands": "Eastern Hill Dispensary",
    "West Industrial": "West Industrial Hospital",
}

DISTRICTS = list(DISTRICT_FACILITIES.keys())
FACILITIES = list(DISTRICT_FACILITIES.values())

# -------------------------------------------------------------------------
# Surveillance Indicator Diseases & Epidemiological Baseline Profiles
# -------------------------------------------------------------------------
DISEASES = {
    "Dengue": {
        "base_lambda": 4.0,
        "peak_hour": 14,
        "category": "Vector-borne",
        "description": "Daytime diurnal peak; sensitive to seasonal and vector conditions.",
    },
    "Influenza": {
        "base_lambda": 6.0,
        "peak_hour": 10,
        "category": "Airborne Respiratory",
        "description": "Morning clinic presentation peak; airborne transmission.",
    },
    "Gastroenteritis": {
        "base_lambda": 2.5,
        "peak_hour": 13,
        "category": "Water/Food-borne",
        "description": "Moderate daytime variation; localized environmental cluster indicator.",
    },
    "Viral Respiratory": {
        "base_lambda": 3.5,
        "peak_hour": 11,
        "category": "General Respiratory",
        "description": "Undifferentiated acute respiratory cluster indicator.",
    },
}

DISEASE_NAMES = list(DISEASES.keys())

# -------------------------------------------------------------------------
# Baseline Seeding Constants (14 Days @ 1-hour resolution)
# -------------------------------------------------------------------------
SEED_DAYS = 14
HOURS_PER_DAY = 24
TOTAL_SEED_HOURS = SEED_DAYS * HOURS_PER_DAY  # 336 hours
TOTAL_SERIES = len(DISTRICTS) * len(DISEASES)  # 5 * 4 = 20 series
TOTAL_EXPECTED_SEED_RECORDS = TOTAL_SERIES * TOTAL_SEED_HOURS  # 20 * 336 = 6,720 records

RANDOM_SEED = 42

# Deterministic reference timestamp: 14 days ending right before live simulation date
# 2026-10-09 00:00:00 UTC to 2026-10-22 23:00:00 UTC (336 hours)
BASELINE_START_TIME = datetime(2026, 10, 9, 0, 0, 0, tzinfo=timezone.utc)

# -------------------------------------------------------------------------
# Detection & Alert Thresholds (Prototype Heuristics)
# -------------------------------------------------------------------------
MIN_HISTORY_POINTS = 14  # Minimum comparable historical hourly points required
THRESHOLD_LOW = 2.5
THRESHOLD_MEDIUM = 3.5
THRESHOLD_HIGH = 5.0
HIGH_MIN_CASES = 10  # Minimum raw cases required alongside High Z-score

ALERT_COOLDOWN_MINUTES = 60

# Prominent synthetic disclaimer banner
SYNTHETIC_DATA_DISCLAIMER = (
    "⚠️ SYNTHETIC DEMONSTRATION PLATFORM — All data is synthetically generated "
    "for academic evaluation. Statistical signals represent alerts for human investigation, "
    "not clinical diagnoses or confirmed public health emergencies."
)
