"""
End-to-End Integration Test for Milestone 5.
Simulates the complete 10-step platform workflow:
1. Baseline seeding reconciliation (6,720 records)
2. Ingestion of normal streaming reports
3. Data validation and quarantine rejection
4. Idempotent duplicate re-transmission suppression
5. Hourly aggregation calculation
6. Injected outbreak surge anomaly detection (Z >= 5.0)
7. Automatic alert generation with priority scoring
8. Local HTML mock-email brief dispatch and persistence
9. Officer triage status transition and audit trail recording
10. System persistence across database restart
"""

from datetime import datetime, timezone
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from alerts import (
    check_alert_recovery,
    get_alert_history,
    process_anomaly_for_alert,
    update_alert_status,
)
from database import get_connection, get_db, init_db, seed_historical_baseline
from detector import detect_and_record_anomaly, get_historical_observations
from pipeline import ingest_record
from simulator import (
    generate_duplicate_retransmission,
    generate_single_report,
    simulate_hour_tick,
)


class TestEndToEndSurveillanceWorkflow(unittest.TestCase):
    """Verifies the complete end-to-end lifecycle in an integrated test environment."""

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "e2e_surveillance.db"
        self.mock_dir = Path(self.temp_dir.name) / "mock_emails"
        self.mock_dir.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_complete_surveillance_and_triage_lifecycle(self):
        # -------------------------------------------------------------
        # Step 1: Database Initialization & 14-Day Seeding
        # -------------------------------------------------------------
        init_db(self.db_path)
        seed_stats = seed_historical_baseline(self.db_path, seed=42, force=True)
        self.assertEqual(seed_stats["status"], "SUCCESS")
        self.assertEqual(seed_stats["raw_records_count"], 6720)
        self.assertEqual(seed_stats["hourly_aggregates_count"], 6720)

        # -------------------------------------------------------------
        # Step 2: Ingest Normal Streaming Batch
        # -------------------------------------------------------------
        tick_res = simulate_hour_tick(self.db_path, seed=100)
        self.assertEqual(tick_res["status"], "SUCCESS")
        self.assertEqual(tick_res["tick_time"], "2026-10-23T00:00:00Z")
        self.assertEqual(tick_res["ingested"], 20)

        # -------------------------------------------------------------
        # Step 3: Verify Validation & Quarantine
        # -------------------------------------------------------------
        bad_record = generate_single_report(
            timestamp=datetime(2026, 10, 23, 0, 0, 0, tzinfo=timezone.utc),
            region="Central Metro",
            disease="Dengue",
            case_count=-5,  # Deliberate negative count
        )
        with get_db(self.db_path) as conn:
            q_res = ingest_record(conn, bad_record, reference_now=datetime(2026, 10, 23, 0, 0, 0, tzinfo=timezone.utc))
            self.assertEqual(q_res["status"], "QUARANTINED")

            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) AS cnt FROM quarantine_records WHERE rejection_reason LIKE '%NEGATIVE_CASE_COUNT%';")
            self.assertEqual(cur.fetchone()["cnt"], 1)

        # -------------------------------------------------------------
        # Step 4: Verify Idempotent Duplicate Suppression
        # -------------------------------------------------------------
        valid_rec = generate_single_report(
            timestamp=datetime(2026, 10, 23, 1, 0, 0, tzinfo=timezone.utc),
            region="North Valley",
            disease="Influenza",
            case_count=7,
            client_submission_id="e2e-dup-nonce",
        )
        with get_db(self.db_path) as conn:
            res_ingest = ingest_record(conn, valid_rec, reference_now=datetime(2026, 10, 23, 1, 0, 0, tzinfo=timezone.utc))
            self.assertEqual(res_ingest["status"], "INGESTED")

            # Retransmit exact duplicate
            dup_rec = generate_duplicate_retransmission(valid_rec)
            res_dup = ingest_record(conn, dup_rec, reference_now=datetime(2026, 10, 23, 1, 0, 0, tzinfo=timezone.utc))
            self.assertEqual(res_dup["status"], "DUPLICATE_REJECTED")

        # -------------------------------------------------------------
        # Step 5: Inject Controlled Outbreak Surge Anomaly
        # -------------------------------------------------------------
        surge_time = "2026-10-23T14:00:00Z"
        surge_dt = datetime(2026, 10, 23, 14, 0, 0, tzinfo=timezone.utc)
        injected_cases = 24  # Baseline median ~4, so 24 cases is a 500% surge

        surge_report = generate_single_report(
            timestamp=surge_dt,
            region="Central Metro",
            disease="Dengue",
            case_count=injected_cases,
        )

        with get_db(self.db_path) as conn:
            # Ingest surge
            ing_res = ingest_record(conn, surge_report, reference_now=surge_dt)
            self.assertEqual(ing_res["status"], "INGESTED")

            # Detect anomaly against 14-day history
            ano_res = detect_and_record_anomaly(
                conn=conn,
                current_count=injected_cases,
                time_bucket=surge_time,
                disease="Dengue",
                region="Central Metro",
                persist=True,
            )

            self.assertTrue(ano_res["is_anomaly"])
            self.assertEqual(ano_res["severity"], "HIGH")
            self.assertGreaterEqual(ano_res["score"], 5.0)

            # Process Alert & Local Mock Email
            alert_res = process_anomaly_for_alert(conn, ano_res, output_dir=self.mock_dir)
            self.assertEqual(alert_res["status"], "ALERT_CREATED")
            alert_id = alert_res["alert_id"]
            self.assertEqual(alert_res["notification"]["status"], "MOCK_SAVED")

            # Verify mock email file exists on disk
            mock_file = Path(alert_res["notification"]["file_path"])
            self.assertTrue(mock_file.exists())
            html_text = mock_file.read_text(encoding="utf-8")
            self.assertIn("LOCAL MOCK NOTIFICATION", html_text)
            self.assertIn("NOT delivered to external networks", html_text)
            self.assertIn("Dengue", html_text)
            self.assertIn("Central Metro", html_text)

        # -------------------------------------------------------------
        # Step 6: Officer Triage & Audit Trail Recording
        # -------------------------------------------------------------
        with get_db(self.db_path) as conn:
            # Officer acknowledges
            res_ack = update_alert_status(
                conn, alert_id, "ACKNOWLEDGED", officer_notes="Reviewed surge; assigned vector inspection unit."
            )
            self.assertEqual(res_ack["new_status"], "ACKNOWLEDGED")

            # Officer moves to investigation
            res_inv = update_alert_status(
                conn, alert_id, "UNDER_INVESTIGATION", officer_notes="Local clinics reporting increased larval density."
            )
            self.assertEqual(res_inv["new_status"], "UNDER_INVESTIGATION")

            # Officer resolves
            res_res = update_alert_status(
                conn, alert_id, "RESOLVED", officer_notes="Fogging completed; case reports returned to baseline."
            )
            self.assertEqual(res_res["new_status"], "RESOLVED")

            # Check audit history
            audit = get_alert_history(conn, alert_id)
            actions = [a["action"] for a in audit]
            self.assertIn("ALERT_CREATED", actions)
            self.assertIn("MOCK_SAVED", actions)
            self.assertIn("OFFICER_ACKNOWLEDGED", actions)
            self.assertIn("OFFICER_UNDER_INVESTIGATION", actions)
            self.assertIn("OFFICER_RESOLVED", actions)

        # -------------------------------------------------------------
        # Step 7: Persistence After Connection Reopen
        # -------------------------------------------------------------
        conn2 = get_connection(self.db_path)
        try:
            cur = conn2.cursor()
            cur.execute("SELECT status, severity FROM alerts WHERE alert_id = ?;", (alert_id,))
            final_row = cur.fetchone()
            self.assertEqual(final_row["status"], "RESOLVED")
            self.assertEqual(final_row["severity"], "HIGH")

            cur.execute("SELECT COUNT(*) AS cnt FROM alert_audit_logs WHERE alert_id = ?;", (alert_id,))
            self.assertGreaterEqual(cur.fetchone()["cnt"], 5)
        finally:
            conn2.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
