"""
Unit tests for Milestone 4: Alert lifecycle, suppression cooldown, and local mock notifications.
Validates alert creation from Medium/High, Low watchlist filtering, 60-min cooldown suppression,
worsening severity escalation, valid/invalid state transitions, normalization detection,
mock email HTML content, failure handling, and audit history immutability.
"""

from datetime import datetime, timedelta, timezone
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from alerts import (
    check_alert_recovery,
    dispatch_local_mock_notification,
    generate_mock_email_html,
    get_alert_history,
    process_anomaly_for_alert,
    update_alert_status,
)
from database import get_connection, get_db, init_db, seed_historical_baseline
from detector import detect_and_record_anomaly


class TestAlertLifecycleAndCooldown(unittest.TestCase):
    """Tests alert creation, cooldown duplicate suppression, and escalation logic."""

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_alerts.db"
        self.mock_dir = Path(self.temp_dir.name) / "mock_emails"
        init_db(self.db_path)

        self.sample_anomaly_med = {
            "anomaly_id": 1,
            "time_bucket": "2026-10-23T14:00:00Z",
            "disease": "Dengue",
            "region": "Central Metro",
            "observed_count": 12,
            "baseline_median": 4.0,
            "dispersion_scale": 2.0,
            "score": 4.0,
            "severity": "MEDIUM",
            "rationale": "Observed count (12) exceeds 14-day median baseline (4.0) by +200.0%.",
        }

        self.sample_anomaly_high = {
            "anomaly_id": 2,
            "time_bucket": "2026-10-23T14:30:00Z",
            "disease": "Dengue",
            "region": "Central Metro",
            "observed_count": 24,
            "baseline_median": 4.0,
            "dispersion_scale": 2.0,
            "score": 10.0,
            "severity": "HIGH",
            "rationale": "Observed count (24) exceeds 14-day median baseline (4.0) by +500.0%.",
        }

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_alert_creation_for_medium_and_high(self):
        """Verifies that Medium and High anomalies create alerts and generate mock emails."""
        with get_db(self.db_path) as conn:
            res_med = process_anomaly_for_alert(conn, self.sample_anomaly_med, output_dir=self.mock_dir)

            self.assertEqual(res_med["status"], "ALERT_CREATED")
            self.assertIsNotNone(res_med["alert_id"])
            self.assertEqual(res_med["severity"], "MEDIUM")
            self.assertEqual(res_med["notification"]["status"], "MOCK_SAVED")

            # Check alerts table
            cur = conn.cursor()
            cur.execute("SELECT * FROM alerts WHERE alert_id = ?;", (res_med["alert_id"],))
            row = cur.fetchone()
            self.assertIsNotNone(row)
            self.assertEqual(row["status"], "PENDING")
            self.assertEqual(row["severity"], "MEDIUM")

            # Verify audit trail has ALERT_CREATED and MOCK_SAVED
            history = get_alert_history(conn, res_med["alert_id"])
            actions = [h["action"] for h in history]
            self.assertIn("ALERT_CREATED", actions)
            self.assertIn("MOCK_SAVED", actions)

    def test_low_severity_anomaly_is_watchlist_only(self):
        """Verifies that Low severity anomalies do NOT generate alerts or mock emails."""
        low_anomaly = dict(self.sample_anomaly_med)
        low_anomaly["severity"] = "LOW"
        low_anomaly["score"] = 2.8

        with get_db(self.db_path) as conn:
            res = process_anomaly_for_alert(conn, low_anomaly, output_dir=self.mock_dir)

            self.assertEqual(res["status"], "WATCHLIST_ONLY")
            self.assertIsNone(res["alert_id"])

            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) AS cnt FROM alerts;")
            self.assertEqual(cur.fetchone()["cnt"], 0)
            cur.execute("SELECT COUNT(*) AS cnt FROM mock_notifications;")
            self.assertEqual(cur.fetchone()["cnt"], 0)

    def test_cooldown_duplicate_suppression_within_60_minutes(self):
        """
        Verifies that repeated anomalies within the 60-minute window for the same
        disease and region do not create duplicate alerts or duplicate mock emails.
        """
        with get_db(self.db_path) as conn:
            # 1. Initial alert at 14:00
            res1 = process_anomaly_for_alert(conn, self.sample_anomaly_med, output_dir=self.mock_dir)
            alert_id = res1["alert_id"]

            # 2. Repeated anomaly at 14:30 (30 min later, within 60 min cooldown) with same Medium severity
            repeat_anomaly = dict(self.sample_anomaly_med)
            repeat_anomaly["time_bucket"] = "2026-10-23T14:30:00Z"
            repeat_anomaly["observed_count"] = 13
            repeat_anomaly["score"] = 4.2

            res2 = process_anomaly_for_alert(conn, repeat_anomaly, output_dir=self.mock_dir)
            self.assertEqual(res2["status"], "COOLDOWN_SUPPRESSED")
            self.assertEqual(res2["alert_id"], alert_id)

            # Assert only ONE alert exists in database
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) AS cnt FROM alerts;")
            self.assertEqual(cur.fetchone()["cnt"], 1)

            # Assert only ONE notification was generated
            cur.execute("SELECT COUNT(*) AS cnt FROM mock_notifications;")
            self.assertEqual(cur.fetchone()["cnt"], 1)

            # Verify audit trail has COOLDOWN_SUPPRESSED record
            history = get_alert_history(conn, alert_id)
            actions = [h["action"] for h in history]
            self.assertIn("COOLDOWN_SUPPRESSED", actions)

    def test_worsening_severity_escalation_within_cooldown(self):
        """
        Verifies that if an anomaly worsens from Medium to High during cooldown:
        - The existing alert is escalated to HIGH.
        - Audit trail logs SEVERITY_ESCALATED.
        - An escalated mock notification brief is dispatched.
        """
        with get_db(self.db_path) as conn:
            # 1. Initial Medium alert at 14:00
            res1 = process_anomaly_for_alert(conn, self.sample_anomaly_med, output_dir=self.mock_dir)
            alert_id = res1["alert_id"]

            # 2. Worsening High surge at 14:30 (30 min later)
            res2 = process_anomaly_for_alert(conn, self.sample_anomaly_high, output_dir=self.mock_dir)
            self.assertEqual(res2["status"], "SEVERITY_ESCALATED")
            self.assertEqual(res2["alert_id"], alert_id)
            self.assertEqual(res2["severity"], "HIGH")

            # Verify alert severity was updated in DB
            cur = conn.cursor()
            cur.execute("SELECT severity FROM alerts WHERE alert_id = ?;", (alert_id,))
            self.assertEqual(cur.fetchone()["severity"], "HIGH")

            # Verify second (escalated) mock email was saved
            cur.execute("SELECT COUNT(*) AS cnt FROM mock_notifications WHERE alert_id = ?;", (alert_id,))
            self.assertEqual(cur.fetchone()["cnt"], 2)

            # Verify audit log recorded escalation
            history = get_alert_history(conn, alert_id)
            actions = [h["action"] for h in history]
            self.assertIn("SEVERITY_ESCALATED", actions)

    def test_valid_lifecycle_transitions(self):
        """Verifies full valid lifecycle: PENDING -> ACKNOWLEDGED -> UNDER_INVESTIGATION -> RESOLVED."""
        with get_db(self.db_path) as conn:
            res = process_anomaly_for_alert(conn, self.sample_anomaly_med, output_dir=self.mock_dir)
            alert_id = res["alert_id"]

            # 1. PENDING -> ACKNOWLEDGED
            res_ack = update_alert_status(
                conn, alert_id, "ACKNOWLEDGED", officer_notes="Reviewed case count trend; dispatched field query."
            )
            self.assertEqual(res_ack["new_status"], "ACKNOWLEDGED")

            # 2. ACKNOWLEDGED -> UNDER_INVESTIGATION
            res_inv = update_alert_status(
                conn, alert_id, "UNDER_INVESTIGATION", officer_notes="Local team collecting vector larvae samples."
            )
            self.assertEqual(res_inv["new_status"], "UNDER_INVESTIGATION")

            # 3. UNDER_INVESTIGATION -> RESOLVED
            res_res = update_alert_status(
                conn, alert_id, "RESOLVED", officer_notes="Vector fogging complete; cases normalized below baseline."
            )
            self.assertEqual(res_res["new_status"], "RESOLVED")

            # Check final DB state
            cur = conn.cursor()
            cur.execute("SELECT status FROM alerts WHERE alert_id = ?;", (alert_id,))
            self.assertEqual(cur.fetchone()["status"], "RESOLVED")

            # Verify complete audit history
            history = get_alert_history(conn, alert_id)
            actions = [h["action"] for h in history]
            self.assertIn("ALERT_CREATED", actions)
            self.assertIn("OFFICER_ACKNOWLEDGED", actions)
            self.assertIn("OFFICER_UNDER_INVESTIGATION", actions)
            self.assertIn("OFFICER_RESOLVED", actions)

    def test_invalid_lifecycle_transitions_rejected(self):
        """Verifies that illegal status transitions raise ValueError."""
        with get_db(self.db_path) as conn:
            res = process_anomaly_for_alert(conn, self.sample_anomaly_med, output_dir=self.mock_dir)
            alert_id = res["alert_id"]

            # Cannot transition directly from PENDING to RESOLVED (must investigate/acknowledge first)
            with self.assertRaises(ValueError):
                update_alert_status(conn, alert_id, "RESOLVED", officer_notes="Skip investigation")

            # Transition to ACKNOWLEDGED
            update_alert_status(conn, alert_id, "ACKNOWLEDGED", officer_notes="Acked")

            # Transition to RESOLVED
            update_alert_status(conn, alert_id, "RESOLVED", officer_notes="Closed")

            # Once RESOLVED (terminal state), cannot transition back to PENDING or UNDER_INVESTIGATION
            with self.assertRaises(ValueError):
                update_alert_status(conn, alert_id, "PENDING", officer_notes="Reopen")

            with self.assertRaises(ValueError):
                update_alert_status(conn, alert_id, "UNDER_INVESTIGATION", officer_notes="Reopen")


class TestMockNotificationContentAndFailure(unittest.TestCase):
    """Tests HTML mock email generation, content safety disclaimers, and error handling."""

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_notif.db"
        self.mock_dir = Path(self.temp_dir.name) / "mock_emails"
        init_db(self.db_path)

        self.alert_dict = {
            "alert_id": "ALT-20261023-TEST",
            "disease": "Dengue",
            "region": "Central Metro",
            "severity": "HIGH",
            "status": "PENDING",
        }
        self.anomaly_dict = {
            "observed_count": 28,
            "baseline_median": 4.0,
            "dispersion_scale": 1.5,
            "score": 16.0,
            "time_bucket": "2026-10-23T14:00:00Z",
            "rationale": "Extreme surge of 28 cases against 4.0 baseline.",
        }

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_mock_email_html_content_and_local_disclaimer(self):
        """Verifies that generated HTML includes the mandatory local disclaimer and key evidence metrics."""
        html = generate_mock_email_html(self.alert_dict, self.anomaly_dict)

        self.assertIn("LOCAL MOCK NOTIFICATION", html)
        self.assertIn("NOT delivered to external networks", html)
        self.assertIn("ALT-20261023-TEST", html)
        self.assertIn("Dengue", html)
        self.assertIn("Central Metro", html)
        self.assertIn("28 cases", html)
        self.assertIn("Z = 16.0", html)
        self.assertIn("Recommended Officer Response Actions", html)

    def test_mock_email_file_write_and_disk_persistence(self):
        """Verifies that mock HTML file is written to disk and logged in mock_notifications table."""
        with get_db(self.db_path) as conn:
            # Insert dummy alert to satisfy foreign key
            conn.execute(
                """
                INSERT INTO detected_anomalies (time_bucket, disease, region, observed_count, baseline_median, dispersion_scale, score, severity, rationale, detected_at)
                VALUES ('2026-10-23T14:00:00Z', 'Dengue', 'Central Metro', 28, 4.0, 1.5, 16.0, 'HIGH', 'Surge', '2026-10-23T14:05:00Z');
                """
            )
            conn.execute(
                """
                INSERT INTO alerts (alert_id, anomaly_id, disease, region, severity, status, created_at, updated_at)
                VALUES ('ALT-20261023-TEST', 1, 'Dengue', 'Central Metro', 'HIGH', 'PENDING', '2026-10-23T14:00:00Z', '2026-10-23T14:00:00Z');
                """
            )

            res = dispatch_local_mock_notification(
                conn, self.alert_dict, self.anomaly_dict, output_dir=self.mock_dir
            )

            self.assertEqual(res["status"], "MOCK_SAVED")
            saved_file = Path(res["file_path"])
            self.assertTrue(saved_file.exists())
            self.assertGreater(saved_file.stat().st_size, 500)

            # Check database entry
            cur = conn.cursor()
            cur.execute("SELECT * FROM mock_notifications WHERE alert_id = 'ALT-20261023-TEST';")
            row = cur.fetchone()
            self.assertIsNotNone(row)
            self.assertEqual(row["status"], "MOCK_SAVED")
            self.assertEqual(row["recipient"], "district-officer@surveillance.local")

    def test_mock_email_file_write_failure_handling(self):
        """
        Verifies that if file writing fails (e.g. invalid target directory path),
        the pipeline does NOT crash, and logs MOCK_FAILED in the database gracefully.
        """
        # Pass a file path as directory (causing an OS error on mkdir)
        invalid_path = Path(self.temp_dir.name) / "blocked_file.txt"
        invalid_path.write_text("Blocking file")
        bad_dir = invalid_path / "subfolder"  # Cannot create directory inside a file

        with get_db(self.db_path) as conn:
            # Insert dummy alert
            conn.execute(
                """
                INSERT INTO detected_anomalies (time_bucket, disease, region, observed_count, baseline_median, dispersion_scale, score, severity, rationale, detected_at)
                VALUES ('2026-10-23T14:00:00Z', 'Dengue', 'Central Metro', 28, 4.0, 1.5, 16.0, 'HIGH', 'Surge', '2026-10-23T14:05:00Z');
                """
            )
            conn.execute(
                """
                INSERT INTO alerts (alert_id, anomaly_id, disease, region, severity, status, created_at, updated_at)
                VALUES ('ALT-20261023-TEST', 1, 'Dengue', 'Central Metro', 'HIGH', 'PENDING', '2026-10-23T14:00:00Z', '2026-10-23T14:00:00Z');
                """
            )

            # Must NOT raise unhandled exception
            res = dispatch_local_mock_notification(
                conn, self.alert_dict, self.anomaly_dict, output_dir=bad_dir
            )

            self.assertEqual(res["status"], "MOCK_FAILED")
            self.assertIsNotNone(res["error_message"])

            # Verify database recorded failure
            cur = conn.cursor()
            cur.execute("SELECT status FROM mock_notifications WHERE alert_id = 'ALT-20261023-TEST';")
            self.assertEqual(cur.fetchone()["status"], "MOCK_FAILED")


class TestRecoveryAndPersistence(unittest.TestCase):
    """Tests normalization / recovery detection and persistence across re-connections."""

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_recov.db"
        self.mock_dir = Path(self.temp_dir.name) / "mock_emails"
        seed_historical_baseline(self.db_path, seed=42, force=True)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_alert_recovery_detection(self):
        """
        Verifies check_alert_recovery correctly identifies 3 consecutive normal hours,
        signaling normalization while leaving alert open for human officer action.
        """
        eval_time = "2026-10-22T23:00:00Z"  # End of baseline
        with get_db(self.db_path) as conn:
            # At baseline, case counts are normal
            recov = check_alert_recovery(
                conn, disease="Dengue", region="Central Metro", current_timestamp=eval_time, consecutive_hours=3
            )
            self.assertTrue(recov["is_recovered"])
            self.assertEqual(recov["consecutive_normal_hours"], 3)
            self.assertIn("Case counts have returned to normal", recov["explanation"])

    def test_alerts_and_audit_persist_after_reconnection(self):
        """Verifies that alerts, audit logs, and mock notification records persist after reconnect."""
        anomaly = {
            "anomaly_id": 1,
            "time_bucket": "2026-10-23T14:00:00Z",
            "disease": "Dengue",
            "region": "Central Metro",
            "observed_count": 22,
            "baseline_median": 4.0,
            "dispersion_scale": 1.5,
            "score": 12.0,
            "severity": "HIGH",
            "rationale": "Outbreak surge",
        }

        with get_db(self.db_path) as conn:
            res = process_anomaly_for_alert(conn, anomaly, output_dir=self.mock_dir)
            alert_id = res["alert_id"]
            update_alert_status(conn, alert_id, "ACKNOWLEDGED", officer_notes="Persistent test check")

        # Explicitly close and reopen connection
        conn2 = get_connection(self.db_path)
        try:
            cur = conn2.cursor()
            cur.execute("SELECT status, severity FROM alerts WHERE alert_id = ?;", (alert_id,))
            row = cur.fetchone()
            self.assertIsNotNone(row)
            self.assertEqual(row["status"], "ACKNOWLEDGED")
            self.assertEqual(row["severity"], "HIGH")

            cur.execute("SELECT COUNT(*) AS cnt FROM alert_audit_logs WHERE alert_id = ?;", (alert_id,))
            self.assertGreaterEqual(cur.fetchone()["cnt"], 3)  # CREATED, MOCK_SAVED, ACKNOWLEDGED

            cur.execute("SELECT status FROM mock_notifications WHERE alert_id = ?;", (alert_id,))
            self.assertEqual(cur.fetchone()["status"], "MOCK_SAVED")
        finally:
            conn2.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
