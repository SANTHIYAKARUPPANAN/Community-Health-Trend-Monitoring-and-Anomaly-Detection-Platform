"""
Statistical Anomaly Detection Engine for Community Health Trend Monitoring.
Implements an explainable, time-matched Median / MAD (Median Absolute Deviation)
detector with a mathematically justified zero-variation fallback hierarchy.
"""

from datetime import datetime, timezone
import math
from pathlib import Path
import sqlite3
import statistics
from typing import Any, Dict, List, Optional, Tuple

from config import (
    HIGH_MIN_CASES,
    MIN_HISTORY_POINTS,
    THRESHOLD_HIGH,
    THRESHOLD_LOW,
    THRESHOLD_MEDIUM,
)


# -------------------------------------------------------------------------
# Robust Scale & Zero-MAD Fallback Calculation
# -------------------------------------------------------------------------
def compute_robust_scale(history: List[float], median_val: float) -> Tuple[float, str]:
    """
    Computes the robust scale estimate (denominator for Z-score).

    Hierarchy:
      Tier 1: Normal-consistent MAD scale (1.4826 * MAD) if MAD > 0.
      Tier 2: Sample standard deviation if MAD == 0 but sample_std > 0.
              (Occurs when >50% of counts are identical, but non-zero variance exists).
      Tier 3: Heuristic scale floor: max(2.0, 0.25 * median) if both MAD == 0 and std == 0.
              (Occurs when 100% of historical values are identical, e.g. all 0s or all 3s).

    Limitations & Prototype Disclaimer:
      This fallback scale floor is an engineering heuristic designed for this
      surveillance prototype to prevent division-by-zero without generating wild
      infinities on tiny count increments. It is NOT a medically validated clinical
      threshold.
    """
    if not history:
        return 2.0, "EMPTY_HISTORY_FLOOR"

    abs_deviations = [abs(x - median_val) for x in history]
    raw_mad = float(statistics.median(abs_deviations))

    # Tier 1: Standard Normal-Consistent MAD
    if raw_mad > 0:
        scale = 1.4826 * raw_mad
        return scale, "MAD"

    # Tier 2: Sample Standard Deviation
    if len(history) > 1:
        sample_std = float(statistics.stdev(history))
        if sample_std > 0:
            return sample_std, "SAMPLE_STD_FALLBACK"

    # Tier 3: Zero-Variation Count Floor
    # Ensures that:
    # - If baseline is 0: observing 1-2 cases yields Z <= 1.0 (Normal).
    # - Observing 8 cases yields Z = 8 / 2.0 = 4.0 (Meaningful Surge).
    floor_scale = max(2.0, 0.25 * float(median_val))
    return floor_scale, "ZERO_VARIATION_FLOOR"


# -------------------------------------------------------------------------
# Prototype Severity Classification
# -------------------------------------------------------------------------
def classify_severity(score: float, current_count: int) -> Tuple[str, bool]:
    """
    Applies agreed prototype severity rules based on deviation score and count volume:
      - Score < 2.5: NORMAL (No anomaly)
      - 2.5 <= Score < 3.5: LOW
      - 3.5 <= Score < 5.0: MEDIUM
      - Score >= 5.0 and current_count >= 10: HIGH
      - Score >= 5.0 and current_count < 10: MEDIUM (Capped at MEDIUM for small numbers)

    Note: When score >= 5.0 but current count < 10, the severity is capped at MEDIUM
    to prevent small-number artifacts (e.g. jumping from 0 to 4 cases) from triggering
    urgent emergency alarms.
    """
    if math.isnan(score) or math.isinf(score):
        return "NORMAL", False

    if score < THRESHOLD_LOW:
        return "NORMAL", False
    elif score < THRESHOLD_MEDIUM:
        return "LOW", True
    elif score < THRESHOLD_HIGH:
        return "MEDIUM", True
    else:
        # Score >= 5.0
        if current_count >= HIGH_MIN_CASES:
            return "HIGH", True
        else:
            # Documented capping for small count artifacts
            return "MEDIUM", True


# -------------------------------------------------------------------------
# Pure Statistical Evaluation Function
# -------------------------------------------------------------------------
def evaluate_observation(
    current_count: int,
    history: List[int],
    time_bucket: str,
    disease: str,
    region: str,
    min_history: int = MIN_HISTORY_POINTS,
) -> Dict[str, Any]:
    """
    Evaluates a single observation against its comparable historical counts.

    Guarantees:
      - Returns INSUFFICIENT_HISTORY if len(history) < min_history.
      - Never divides by zero or emits NaN / Inf.
      - Generates an explainable text rationale.
    """
    sample_count = len(history)

    # 1. Cold-start check
    if sample_count < min_history:
        return {
            "status": "INSUFFICIENT_HISTORY",
            "is_anomaly": False,
            "severity": "NORMAL",
            "score": None,
            "baseline_median": None,
            "dispersion_scale": None,
            "scale_method": "NONE",
            "sample_count": sample_count,
            "observed_count": current_count,
            "time_bucket": time_bucket,
            "disease": disease,
            "region": region,
            "rationale": (
                f"Insufficient historical observations ({sample_count}/{min_history} required points). "
                f"Anomaly detection suppressed."
            ),
        }

    # 2. Historical baseline calculation
    float_history = [float(x) for x in history]
    median_val = float(statistics.median(float_history))
    scale, scale_method = compute_robust_scale(float_history, median_val)

    # 3. Deviation score calculation
    if scale > 0:
        score = (float(current_count) - median_val) / scale
    else:
        score = 0.0

    # Ensure finite numeric score
    if math.isnan(score) or math.isinf(score):
        score = 0.0

    # 4. Severity classification
    severity, is_anomaly = classify_severity(score, current_count)

    # 5. Explainable rationale generation
    if median_val > 0:
        pct_diff = ((current_count - median_val) / median_val) * 100.0
        diff_str = f"+{pct_diff:.1f}%" if pct_diff >= 0 else f"{pct_diff:.1f}%"
    else:
        diff_str = f"+{current_count} cases above zero baseline"

    if is_anomaly:
        rationale = (
            f"Observed count ({current_count}) exceeds 14-day median baseline ({median_val:.1f}) "
            f"by {diff_str} with deviation score Z = {score:.2f} (scale = {scale:.2f}, "
            f"method = {scale_method}, N = {sample_count}), triggering a {severity} anomaly signal."
        )
    else:
        rationale = (
            f"Observed count ({current_count}) is within normal variance of 14-day median baseline "
            f"({median_val:.1f}) with deviation score Z = {score:.2f} (scale = {scale:.2f}, "
            f"method = {scale_method}, N = {sample_count})."
        )

    return {
        "status": "EVALUATED",
        "is_anomaly": is_anomaly,
        "severity": severity,
        "score": round(score, 4),
        "baseline_median": round(median_val, 2),
        "dispersion_scale": round(scale, 4),
        "scale_method": scale_method,
        "sample_count": sample_count,
        "observed_count": current_count,
        "time_bucket": time_bucket,
        "disease": disease,
        "region": region,
        "rationale": rationale,
    }


# -------------------------------------------------------------------------
# Database Query & Anomaly Persistence
# -------------------------------------------------------------------------
def get_historical_observations(
    conn: sqlite3.Connection,
    disease: str,
    region: str,
    current_timestamp: str,
    max_points: int = 14,
) -> List[int]:
    """
    Extracts time-matched historical counts from hourly_aggregates.

    Constraints:
      - Strictly precedes current_timestamp (time_bucket < current_timestamp).
      - Matches the exact hour of day: strftime('%H', time_bucket) == strftime('%H', current_timestamp).
      - Returns up to max_points (default 14) ordered chronologically.
    """
    # Extract HH from current_timestamp (supports ISO format like '2026-10-23T14:00:00Z')
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT total_cases, time_bucket
        FROM hourly_aggregates
        WHERE disease = ?
          AND region = ?
          AND time_bucket < ?
          AND strftime('%H', time_bucket) = strftime('%H', ?)
        ORDER BY time_bucket DESC
        LIMIT ?;
        """,
        (disease, region, current_timestamp, current_timestamp, max_points),
    )
    rows = cursor.fetchall()
    # Reverse to return chronological order [D-14, D-13, ..., D-1]
    return [row["total_cases"] for row in reversed(rows)]


def detect_and_record_anomaly(
    conn: sqlite3.Connection,
    current_count: int,
    time_bucket: str,
    disease: str,
    region: str,
    persist: bool = True,
    min_history: int = MIN_HISTORY_POINTS,
) -> Dict[str, Any]:
    """
    Queries historical counts, evaluates the observation, and optionally persists
    qualifying anomalies into the detected_anomalies table.
    """
    history = get_historical_observations(conn, disease, region, time_bucket, max_points=min_history)
    result = evaluate_observation(
        current_count=current_count,
        history=history,
        time_bucket=time_bucket,
        disease=disease,
        region=region,
        min_history=min_history,
    )

    if persist and result["is_anomaly"]:
        now_str = datetime.now(timezone.utc).isoformat()
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO detected_anomalies (
                time_bucket, disease, region, observed_count,
                baseline_median, dispersion_scale, score, severity,
                rationale, detected_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """,
            (
                result["time_bucket"],
                result["disease"],
                result["region"],
                result["observed_count"],
                result["baseline_median"],
                result["dispersion_scale"],
                result["score"],
                result["severity"],
                result["rationale"],
                now_str,
            ),
        )
        result["anomaly_id"] = cursor.lastrowid

    return result


def scan_hour_anomalies(
    conn: sqlite3.Connection,
    time_bucket: str,
    persist: bool = True,
) -> List[Dict[str, Any]]:
    """
    Scans all disease and region series for a given hourly time_bucket,
    evaluating anomalies against each series' historical baseline.
    """
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT aggregate_id, time_bucket, disease, region, total_cases
        FROM hourly_aggregates
        WHERE time_bucket = ?;
        """,
        (time_bucket,),
    )
    rows = cursor.fetchall()
    anomalies = []

    for row in rows:
        eval_res = detect_and_record_anomaly(
            conn=conn,
            current_count=row["total_cases"],
            time_bucket=row["time_bucket"],
            disease=row["disease"],
            region=row["region"],
            persist=persist,
        )
        if eval_res["is_anomaly"]:
            anomalies.append(eval_res)

    return anomalies
