"""
Styles and UI Design System for Community Health Trend Monitoring & Anomaly Detection.
Implements the Hybrid Enterprise design language:
- Dark Navy Sidebar (#0F172A / #1E293B) with high-contrast slate typography.
- Crisp Light Content Canvas (#F8FAFC / #FFFFFF) with subtle neutral borders (#E2E8F0).
- Restrained Public-Health Teal Accents (#0D9488 / #14B8A6).
- Accessible Semantic Alert Severity & Lifecycle Status Badges.
- Unified Plotly Layout Configuration with muted gridlines and crisp hover cards.
"""

from typing import Any, Dict, Optional
import streamlit as st

# -------------------------------------------------------------------------
# Global Enterprise CSS
# -------------------------------------------------------------------------
ENTERPRISE_CSS = """
<style>
  /* Base typography & Canvas */
  html, body, [class*="css"] {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  }
  .main .block-container {
      padding-top: 1.5rem;
      padding-bottom: 3rem;
      max-width: 1400px;
  }
  
  /* Top App Header Banner */
  .app-header-container {
      background: #FFFFFF;
      border: 1px solid #E2E8F0;
      border-radius: 8px;
      padding: 16px 24px;
      margin-bottom: 14px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 1px 3px rgba(0,0,0,0.03);
  }
  .app-header-title {
      font-size: 22px;
      font-weight: 700;
      color: #0F172A;
      margin: 0;
      letter-spacing: -0.02em;
  }
  .app-header-subtitle {
      font-size: 13px;
      color: #64748B;
      margin-top: 3px;
  }
  .app-header-meta {
      display: flex;
      gap: 12px;
      align-items: center;
  }
  .status-pill-live {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: #ECFDF5;
      color: #065F46;
      border: 1px solid #A7F3D0;
      padding: 4px 10px;
      border-radius: 16px;
      font-size: 12px;
      font-weight: 600;
  }
  .status-pill-clock {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: #F1F5F9;
      color: #334155;
      border: 1px solid #CBD5E1;
      padding: 4px 12px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 600;
      font-family: monospace;
  }
  
  /* Mandatory Synthetic Disclaimer Banner */
  .disclaimer-banner {
      background: #FFFBEB;
      border: 1px solid #FDE68A;
      border-left: 4px solid #D97706;
      border-radius: 6px;
      padding: 10px 16px;
      color: #92400E;
      font-size: 12px;
      line-height: 1.5;
      margin-bottom: 18px;
  }
  .disclaimer-banner strong {
      color: #78350F;
  }

  /* Dark Navy Sidebar Overrides */
  [data-testid="stSidebar"] {
      background-color: #0F172A !important;
      border-right: 1px solid #1E293B;
  }
  [data-testid="stSidebar"] [data-testid="stMarkdownContainer"] p,
  [data-testid="stSidebar"] [data-testid="stMarkdownContainer"] span,
  [data-testid="stSidebar"] [data-testid="stMarkdownContainer"] label {
      color: #E2E8F0 !important;
  }
  [data-testid="stSidebar"] h1,
  [data-testid="stSidebar"] h2,
  [data-testid="stSidebar"] h3 {
      color: #F8FAFC !important;
      font-weight: 700 !important;
      letter-spacing: -0.01em;
  }
  [data-testid="stSidebar"] hr {
      border-color: #334155 !important;
      margin: 16px 0 !important;
  }
  [data-testid="stSidebar"] .stMetric {
      background: #1E293B;
      padding: 10px 14px;
      border-radius: 6px;
      border: 1px solid #334155;
      margin-bottom: 8px;
  }
  [data-testid="stSidebar"] [data-testid="stMetricLabel"] {
      color: #94A3B8 !important;
      font-size: 11px !important;
      text-transform: uppercase !important;
      letter-spacing: 0.05em !important;
  }
  [data-testid="stSidebar"] [data-testid="stMetricValue"] {
      color: #F8FAFC !important;
      font-size: 18px !important;
      font-weight: 700 !important;
  }
  
  /* Sidebar Action Buttons */
  [data-testid="stSidebar"] .stButton > button {
      background: #1E293B !important;
      color: #F8FAFC !important;
      border: 1px solid #334155 !important;
      border-radius: 6px !important;
      font-weight: 600 !important;
      font-size: 13px !important;
      transition: all 0.15s ease-in-out !important;
  }
  [data-testid="stSidebar"] .stButton > button:hover {
      background: #0D9488 !important;
      color: #FFFFFF !important;
      border-color: #0D9488 !important;
  }

  /* Enterprise Card Containers */
  .enterprise-card {
      background: #FFFFFF;
      border: 1px solid #E2E8F0;
      border-radius: 8px;
      padding: 18px 20px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.03);
      margin-bottom: 16px;
  }
  .card-header-title {
      font-size: 15px;
      font-weight: 700;
      color: #0F172A;
      margin-bottom: 12px;
      display: flex;
      align-items: center;
      gap: 8px;
  }
  
  /* Custom Metric Cards */
  .kpi-container {
      background: #FFFFFF;
      border: 1px solid #E2E8F0;
      border-radius: 8px;
      padding: 14px 16px;
      box-shadow: 0 1px 2px rgba(0,0,0,0.02);
      border-top: 3px solid #0D9488;
      height: 100%;
  }
  .kpi-label {
      font-size: 11px;
      font-weight: 600;
      color: #64748B;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      margin-bottom: 4px;
  }
  .kpi-num {
      font-size: 24px;
      font-weight: 700;
      color: #0F172A;
      line-height: 1.2;
      margin-bottom: 4px;
      font-variant-numeric: tabular-nums;
  }
  .kpi-desc {
      font-size: 11px;
      color: #94A3B8;
  }
  
  /* Semantic Badges */
  .badge-high {
      display: inline-block;
      background: #FEF2F2;
      color: #DC2626;
      border: 1px solid #FCA5A5;
      padding: 2px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.02em;
  }
  .badge-medium {
      display: inline-block;
      background: #FFFBEB;
      color: #D97706;
      border: 1px solid #FCD34D;
      padding: 2px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.02em;
  }
  .badge-low {
      display: inline-block;
      background: #EFF6FF;
      color: #2563EB;
      border: 1px solid #93C5FD;
      padding: 2px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.02em;
  }
  .badge-normal {
      display: inline-block;
      background: #ECFDF5;
      color: #059669;
      border: 1px solid #6EE7B7;
      padding: 2px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.02em;
  }
  
  /* Lifecycle Status Badges */
  .status-pending {
      display: inline-block;
      background: #FFFBEB;
      color: #B45309;
      border: 1px solid #FDE68A;
      padding: 3px 9px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
  }
  .status-acknowledged {
      display: inline-block;
      background: #EFF6FF;
      color: #1D4ED8;
      border: 1px solid #BFDBFE;
      padding: 3px 9px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
  }
  .status-under_investigation {
      display: inline-block;
      background: #F5F3FF;
      color: #6D28D9;
      border: 1px solid #DDD6FE;
      padding: 3px 9px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
  }
  .status-resolved {
      display: inline-block;
      background: #ECFDF5;
      color: #047857;
      border: 1px solid #A7F3D0;
      padding: 3px 9px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
  }

  /* Evidence Dossier Container */
  .evidence-dossier {
      background: #F8FAFC;
      border: 1px solid #E2E8F0;
      border-left: 4px solid #0D9488;
      border-radius: 0 8px 8px 0;
      padding: 16px 20px;
      margin-top: 14px;
  }
  .evidence-header {
      font-size: 13px;
      font-weight: 700;
      color: #0F172A;
      margin-bottom: 8px;
  }
  .evidence-rationale {
      font-size: 13px;
      color: #334155;
      line-height: 1.5;
  }

  /* Audit Timeline Item */
  .timeline-item {
      position: relative;
      padding-left: 24px;
      margin-bottom: 16px;
      border-left: 2px solid #E2E8F0;
  }
  .timeline-dot {
      position: absolute;
      left: -6px;
      top: 2px;
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background: #0D9488;
  }
  .timeline-time {
      font-size: 11px;
      color: #64748B;
      font-family: monospace;
      margin-bottom: 2px;
  }
  .timeline-action {
      font-size: 13px;
      font-weight: 700;
      color: #0F172A;
  }
  .timeline-notes {
      font-size: 12px;
      color: #475569;
      background: #F8FAFC;
      border: 1px solid #E2E8F0;
      border-radius: 4px;
      padding: 6px 10px;
      margin-top: 4px;
  }

  /* Streamlit Tabs Polish */
  .stTabs [data-baseweb="tab-list"] {
      gap: 8px;
      border-bottom: 1px solid #E2E8F0;
      padding-bottom: 2px;
  }
  .stTabs [data-baseweb="tab"] {
      border-radius: 6px 6px 0 0;
      padding: 10px 18px;
      color: #64748B;
      font-weight: 600;
      font-size: 13px;
      background-color: transparent;
      border: none;
  }
  .stTabs [aria-selected="true"] {
      color: #0D9488 !important;
      border-bottom: 2px solid #0D9488 !important;
      background-color: #FFFFFF !important;
  }
</style>
"""

# -------------------------------------------------------------------------
# UI Rendering Helpers
# -------------------------------------------------------------------------
def apply_enterprise_theme():
    """Injects the global CSS design tokens into the Streamlit app."""
    st.markdown(ENTERPRISE_CSS, unsafe_allow_html=True)


def render_app_header(latest_timestamp: Optional[str] = None):
    """Renders the top application header with operational status and surveillance clock."""
    clock_display = "INITIALIZING..."
    if latest_timestamp:
        clock_display = latest_timestamp.replace("T", " ").replace(":00:00Z", ":00 UTC")

    st.markdown(
        f"""
        <div class="app-header-container">
          <div>
            <div class="app-header-title">🏥 Community Health Trend Monitoring & Anomaly Detection</div>
            <div class="app-header-subtitle">Automated Epidemiological Surveillance & Officer Decision-Support System</div>
          </div>
          <div class="app-header-meta">
            <div class="status-pill-live">
              <span style="font-size: 9px;">🟢</span> NODE ACTIVE
            </div>
            <div class="status-pill-clock" title="Current surveillance reference timestamp">
              🕒 {clock_display}
            </div>
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_disclaimer_banner():
    """Renders the mandatory synthetic data and prototype decision-support banner."""
    st.markdown(
        """
        <div class="disclaimer-banner">
          <strong>⚠️ SYNTHETIC DEMONSTRATION PLATFORM:</strong>
          All records, reporting facilities, and baseline distributions are synthetically simulated for academic evaluation.
          Statistical anomaly signals represent alerts for human investigation, <strong>not confirmed clinical diagnoses,
          public health declarations, or medical verdicts</strong>.
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_kpi_card(label: str, value: Any, description: str, border_accent: str = "#0D9488"):
    """Renders a styled enterprise KPI metric card."""
    st.markdown(
        f"""
        <div class="kpi-container" style="border-top-color: {border_accent};">
          <div class="kpi-label">{label}</div>
          <div class="kpi-num">{value}</div>
          <div class="kpi-desc">{description}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def get_severity_badge_html(severity: str) -> str:
    """Returns styled HTML badge for an anomaly severity level."""
    s = str(severity).upper()
    if s == "HIGH":
        return '<span class="badge-high">HIGH PRIORITY</span>'
    elif s == "MEDIUM":
        return '<span class="badge-medium">MEDIUM PRIORITY</span>'
    elif s == "LOW":
        return '<span class="badge-low">LOW WATCHLIST</span>'
    return '<span class="badge-normal">NORMAL</span>'


def get_status_badge_html(status: str) -> str:
    """Returns styled HTML badge for an alert lifecycle status."""
    st_val = str(status).upper()
    if st_val == "PENDING":
        return '<span class="status-pending">● PENDING TRIAGE</span>'
    elif st_val == "ACKNOWLEDGED":
        return '<span class="status-acknowledged">✓ ACKNOWLEDGED</span>'
    elif st_val == "UNDER_INVESTIGATION":
        return '<span class="status-under_investigation">🔍 INVESTIGATING</span>'
    elif st_val == "RESOLVED":
        return '<span class="status-resolved">✓ RESOLVED</span>'
    return f'<span>{status}</span>'


def render_section_title(title: str, subtitle: Optional[str] = None):
    """Renders a structured section title with a teal accent bar."""
    sub_html = f'<div style="font-size: 13px; color: #64748B; margin-top: 2px;">{subtitle}</div>' if subtitle else ""
    st.markdown(
        f"""
        <div style="margin: 20px 0 12px 0; border-left: 3px solid #0D9488; padding-left: 10px;">
          <div style="font-size: 16px; font-weight: 700; color: #0F172A; letter-spacing: -0.01em;">{title}</div>
          {sub_html}
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_evidence_dossier(
    observed: float,
    baseline: float,
    scale: float,
    scale_method: str,
    score: float,
    severity: str,
    rationale: str,
    time_bucket: str,
    sample_size: int = 14,
):
    """Renders an epidemiological evidence dossier card for a flagged anomaly."""
    badge_html = get_severity_badge_html(severity)
    pct_diff = ((observed - baseline) / max(0.1, baseline)) * 100.0
    sign = "+" if pct_diff >= 0 else ""

    st.markdown(
        f"""
        <div class="evidence-dossier">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <div class="evidence-header">
              🔬 STATISTICAL EVIDENCE DOSSIER &bull; <span style="font-family: monospace; font-weight: 600;">{time_bucket}</span>
            </div>
            <div>{badge_html}</div>
          </div>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 10px; margin-bottom: 12px;">
            <div style="background: #FFFFFF; border: 1px solid #E2E8F0; padding: 10px; border-radius: 6px;">
              <div style="font-size: 11px; color: #64748B; font-weight: 600; text-transform: uppercase;">Observed Cases</div>
              <div style="font-size: 20px; font-weight: 700; color: #0F172A;">{int(observed)}</div>
              <div style="font-size: 11px; color: {'#DC2626' if pct_diff > 0 else '#64748B'}; font-weight: 600;">{sign}{pct_diff:.1f}% vs median</div>
            </div>
            <div style="background: #FFFFFF; border: 1px solid #E2E8F0; padding: 10px; border-radius: 6px;">
              <div style="font-size: 11px; color: #64748B; font-weight: 600; text-transform: uppercase;">14d Median Baseline</div>
              <div style="font-size: 20px; font-weight: 700; color: #0F172A;">{baseline:.1f}</div>
              <div style="font-size: 11px; color: #64748B;">N = {sample_size} days</div>
            </div>
            <div style="background: #FFFFFF; border: 1px solid #E2E8F0; padding: 10px; border-radius: 6px;">
              <div style="font-size: 11px; color: #64748B; font-weight: 600; text-transform: uppercase;">Robust Scale (ŝ)</div>
              <div style="font-size: 20px; font-weight: 700; color: #0F172A;">{scale:.2f}</div>
              <div style="font-size: 10px; color: #64748B; font-family: monospace;">{scale_method}</div>
            </div>
            <div style="background: #FFFFFF; border: 1px solid #E2E8F0; padding: 10px; border-radius: 6px;">
              <div style="font-size: 11px; color: #64748B; font-weight: 600; text-transform: uppercase;">Deviation Score</div>
              <div style="font-size: 20px; font-weight: 700; color: {'#DC2626' if score >= 5.0 else ('#D97706' if score >= 3.5 else '#2563EB')};">Z = {score:.2f}</div>
              <div style="font-size: 11px; color: #64748B;">Cutoff ≥ 2.5</div>
            </div>
          </div>
          <div style="background: #FFFFFF; border: 1px solid #E2E8F0; padding: 12px 14px; border-radius: 6px;">
            <div style="font-size: 11px; font-weight: 700; color: #475569; text-transform: uppercase; margin-bottom: 4px;">Algorithmic Decision Rationale</div>
            <div class="evidence-rationale">{rationale}</div>
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def get_plotly_theme() -> Dict[str, Any]:
    """Returns standard Plotly layout parameters conforming to Hybrid Enterprise style."""
    return dict(
        font=dict(family='-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', color='#0F172A'),
        plot_bgcolor="#FFFFFF",
        paper_bgcolor="#FFFFFF",
        hoverlabel=dict(bgcolor="#0F172A", font_size=12, font_color="#FFFFFF", font_family="monospace"),
        xaxis=dict(
            showgrid=True,
            gridcolor="#F1F5F9",
            zeroline=False,
            linecolor="#E2E8F0",
            tickfont=dict(size=11, color="#64748B"),
            titlefont=dict(size=12, color="#334155"),
        ),
        yaxis=dict(
            showgrid=True,
            gridcolor="#F1F5F9",
            zeroline=False,
            linecolor="#E2E8F0",
            tickfont=dict(size=11, color="#64748B"),
            titlefont=dict(size=12, color="#334155"),
        ),
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1.0,
            font=dict(size=11, color="#475569"),
        ),
        margin=dict(l=40, r=40, t=50, b=40),
    )
