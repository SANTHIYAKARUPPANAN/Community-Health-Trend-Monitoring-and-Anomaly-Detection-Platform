"""
Community Health Trend Monitoring & Anomaly Detection Platform.
Professional Health Authority Command Center (Streamlit Dashboard).
Provides live surveillance monitoring, interactive Plotly trend analysis,
alert triage with audit trails, and outbreak demonstration controls.
"""

from datetime import datetime, timedelta, timezone
from pathlib import Path
import sqlite3
import statistics
import sys
from typing import Any, Dict, List, Optional

import pandas as pd
import streamlit as st

# Ensure project root is in python path
BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from alerts import (
    ALLOWED_TRANSITIONS,
    check_alert_recovery,
    get_alert_history,
    process_anomaly_for_alert,
    update_alert_status,
)
from config import (
    DB_PATH,
    DISEASE_NAMES,
    DISEASES,
    DISTRICT_FACILITIES,
    DISTRICTS,
    MOCK_EMAIL_DIR,
    SYNTHETIC_DATA_DISCLAIMER,
)
from database import get_connection, get_db, init_db, seed_historical_baseline
from detector import (
    compute_robust_scale,
    detect_and_record_anomaly,
    evaluate_observation,
    get_historical_observations,
    scan_hour_anomalies,
)
from pipeline import ingest_record
from simulator import generate_single_report, simulate_hour_tick
from styles import (
    apply_enterprise_theme,
    get_plotly_theme,
    get_severity_badge_html,
    get_status_badge_html,
    render_app_header,
    render_disclaimer_banner,
    render_evidence_dossier,
    render_kpi_card,
    render_section_title,
)

# Optional Plotly import with fallback
try:
    import plotly.graph_objects as go
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

# -------------------------------------------------------------------------
# Page Configuration & Hybrid Enterprise Styling
# -------------------------------------------------------------------------
st.set_page_config(
    page_title="Community Health Surveillance",
    page_icon="🏥",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Apply global Hybrid Enterprise design tokens
apply_enterprise_theme()

# Ensure DB exists
if not DB_PATH.exists():
    init_db(DB_PATH)
    seed_historical_baseline(DB_PATH, force=False)

# Fetch global operational state for header & sidebar
with get_connection(DB_PATH) as conn:
    cur = conn.cursor()
    cur.execute("SELECT MAX(timestamp) AS latest_ts FROM raw_records;")
    latest_ts = cur.fetchone()["latest_ts"]
    cur.execute("SELECT COUNT(*) AS cnt FROM raw_records;")
    total_raw = cur.fetchone()["cnt"]
    cur.execute("SELECT COUNT(*) AS cnt FROM alerts WHERE status != 'RESOLVED';")
    active_alerts_cnt = cur.fetchone()["cnt"]

# -------------------------------------------------------------------------
# Sidebar: System Health & Simulation Execution Controls
# -------------------------------------------------------------------------
with st.sidebar:
    st.markdown("### 🏥 System Status")
    st.markdown("🟢 **Surveillance Node:** Active")
    st.markdown(f"💾 **Storage:** SQLite (WAL Mode)")
    st.markdown(f"📍 **Districts:** {len(DISTRICTS)} Registered")
    st.markdown(f"🦠 **Conditions:** {len(DISEASES)} Monitored")

    st.markdown("---")
    st.markdown("### 📊 Live Surveillance Telemetry")
    clock_formatted = latest_ts.replace("T", " ").replace(":00:00Z", ":00 UTC") if latest_ts else "INITIALIZING..."
    st.metric("Surveillance Clock", clock_formatted)
    st.metric("Validated Case Reports", f"{total_raw:,}")
    st.metric("Active / Unresolved Alerts", active_alerts_cnt)

    st.markdown("---")
    st.markdown("### ⚙️ Simulation Stepper")

    if st.button("▶ Step 1 Hour", use_container_width=True, help="Advance simulation clock by 1 hour and process incoming census reports"):
        tick_res = simulate_hour_tick(DB_PATH)
        # Scan anomalies for this new tick
        with get_db(DB_PATH) as conn:
            anomalies = scan_hour_anomalies(conn, tick_res["tick_time"], persist=True)
            for a in anomalies:
                process_anomaly_for_alert(conn, a)
        st.success(f"Simulated {tick_res['tick_time']} (+{tick_res['ingested']} reports)")
        st.rerun()

    if st.button("⏩ Step 6 Hours", use_container_width=True, help="Advance simulation clock by 6 hours"):
        for _ in range(6):
            tick_res = simulate_hour_tick(DB_PATH)
            with get_db(DB_PATH) as conn:
                anomalies = scan_hour_anomalies(conn, tick_res["tick_time"], persist=True)
                for a in anomalies:
                    process_anomaly_for_alert(conn, a)
        st.success("Advanced simulation by 6 hours.")
        st.rerun()

    if st.button("🔄 Reset 14-Day Baseline", use_container_width=True, help="Resets DB to clean initial 14-day seed (6,720 records)"):
        stats = seed_historical_baseline(DB_PATH, force=True)
        st.warning(f"Reset database to 14-day baseline ({stats['raw_records_count']} records).")
        st.rerun()

# -------------------------------------------------------------------------
# Top Header & Navigation
# -------------------------------------------------------------------------
render_app_header(latest_ts)

tab1, tab2, tab3, tab4 = st.tabs([
    "📊 Surveillance Overview",
    "📈 Trends & Anomaly Explorer",
    "🚨 Alert Investigation & Audit",
    "💥 Outbreak Demo & Reporting",
])


# =========================================================================
# TAB 1: Surveillance Overview
# =========================================================================
with tab1:
    render_disclaimer_banner()

    # 1. Operational Telemetry & Health Authority KPIs
    with get_connection(DB_PATH) as conn:
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) AS cnt FROM raw_records;")
        raw_cnt = cur.fetchone()["cnt"]
        cur.execute("SELECT COUNT(*) AS cnt FROM quarantine_records;")
        quarantine_cnt = cur.fetchone()["cnt"]
        cur.execute("SELECT COUNT(*) AS cnt FROM alerts WHERE status = 'PENDING';")
        pending_cnt = cur.fetchone()["cnt"]
        cur.execute("SELECT COUNT(*) AS cnt FROM alerts WHERE status IN ('ACKNOWLEDGED', 'UNDER_INVESTIGATION');")
        in_investigation_cnt = cur.fetchone()["cnt"]
        cur.execute("SELECT SUM(total_cases) AS total_cases FROM hourly_aggregates;")
        total_cases_all = cur.fetchone()["total_cases"] or 0
        cur.execute("SELECT COUNT(DISTINCT facility_id) AS fac_cnt FROM raw_records;")
        fac_count = cur.fetchone()["fac_cnt"] or len(DISTRICT_FACILITIES)

    total_submissions = raw_cnt + quarantine_cnt
    hygiene_rate = (raw_cnt / max(1, total_submissions)) * 100.0

    col1, col2, col3, col4, col5 = st.columns(5)
    with col1:
        render_kpi_card("Total Case Reports", f"{total_cases_all:,}", "Cumulative cases across all districts", "#0D9488")
    with col2:
        render_kpi_card("Reporting Facilities", f"{fac_count} / {len(DISTRICT_FACILITIES)} Active", "100% facility node coverage", "#2563EB")
    with col3:
        render_kpi_card("Data Hygiene Rate", f"{hygiene_rate:.1f}% Valid", f"{raw_cnt:,} passed · {quarantine_cnt} quarantined", "#10B981")
    with col4:
        pending_color = "#DC2626" if pending_cnt > 0 else "#64748B"
        render_kpi_card("Pending Triage Alerts", f"{pending_cnt}", "Awaiting health officer review", pending_color)
    with col5:
        render_kpi_card("Active Investigations", f"{in_investigation_cnt}", "Currently in officer workflow", "#7C3AED")

    # 2. Executive Alert Triage Glance
    with get_connection(DB_PATH) as conn:
        df_recent_alerts = pd.read_sql_query(
            """
            SELECT alert_id AS "Alert ID",
                   disease AS "Condition",
                   region AS "District",
                   severity AS "Severity",
                   status AS "Status",
                   created_at AS "Detected At"
            FROM alerts
            WHERE status != 'RESOLVED'
            ORDER BY created_at DESC
            LIMIT 5;
            """,
            conn,
        )

    render_section_title("🚨 Priority Alert Surveillance Feed", "Active alerts requiring health authority attention (unresolved)")
    if not df_recent_alerts.empty:
        st.dataframe(df_recent_alerts, use_container_width=True, hide_index=True)
    else:
        st.success("🟢 No active alerts. All surveillance series are currently operating within baseline expectations.")

    # 3. Cross-District Case Distribution Overview
    render_section_title("🗺️ Surveillance District Comparative Activity", "Reported case volume across registered districts (Last 48 Hours)")
    with get_connection(DB_PATH) as conn:
        df_dist_cases = pd.read_sql_query(
            """
            SELECT region,
                   SUM(total_cases) AS total_cases
            FROM hourly_aggregates
            WHERE time_bucket >= (SELECT datetime(MAX(time_bucket), '-48 hours') FROM hourly_aggregates)
            GROUP BY region
            ORDER BY total_cases DESC;
            """,
            conn,
        )

    if not df_dist_cases.empty and HAS_PLOTLY:
        fig_bar = go.Figure(
            data=[
                go.Bar(
                    x=df_dist_cases["region"],
                    y=df_dist_cases["total_cases"],
                    marker=dict(
                        color=["#0D9488", "#14B8A6", "#2DD4BF", "#5EEAD4", "#99F6E4"],
                        line=dict(color="#0F766E", width=1),
                    ),
                    text=df_dist_cases["total_cases"],
                    textposition="auto",
                    hovertemplate="<b>%{x}</b><br>48h Case Reports: %{y}<extra></extra>",
                )
            ]
        )
        bar_layout = get_plotly_theme()
        bar_layout.update(
            title=dict(text="Comparative 48-Hour Case Burden by Surveillance District", font=dict(size=14, color="#0F172A")),
            height=280,
            xaxis=dict(title="Surveillance District", tickangle=0),
            yaxis=dict(title="Reported Cases (48h Sum)"),
            margin=dict(l=40, r=40, t=40, b=40),
        )
        fig_bar.update_layout(bar_layout)
        st.plotly_chart(fig_bar, use_container_width=True)

    # 4. Live Ingestion Stream & Quarantine Analytics
    col_stream, col_quar = st.columns([3, 2])
    with col_stream:
        render_section_title("⚡ Facility Census Ingestion Feed", "Real-time stream of validated incoming clinic census batches")
        with get_connection(DB_PATH) as conn:
            df_recent = pd.read_sql_query(
                """
                SELECT timestamp AS "Report Hour",
                       facility_id AS "Facility",
                       region AS "District",
                       disease AS "Condition",
                       case_count AS "Cases",
                       client_submission_id AS "Nonce",
                       created_at AS "Ingested At"
                FROM raw_records
                ORDER BY timestamp DESC, created_at DESC
                LIMIT 10;
                """,
                conn,
            )
        st.dataframe(df_recent, use_container_width=True, hide_index=True)

    with col_quar:
        render_section_title("🛡️ Data Hygiene & Quarantine", "Payloads rejected due to validation failure or duplicate nonces")
        with get_connection(DB_PATH) as conn:
            df_quar_summary = pd.read_sql_query(
                """
                SELECT rejection_reason AS "Rejection Reason",
                       COUNT(*) AS "Count"
                FROM quarantine_records
                GROUP BY rejection_reason
                ORDER BY "Count" DESC;
                """,
                conn,
            )
        if not df_quar_summary.empty:
            st.dataframe(df_quar_summary, use_container_width=True, hide_index=True)
            with st.expander(f"Inspect Quarantined Raw Payloads ({quarantine_cnt})"):
                with get_connection(DB_PATH) as conn:
                    df_quar_raw = pd.read_sql_query(
                        """
                        SELECT quarantine_id AS "ID",
                               detected_at AS "Rejected At",
                               rejection_reason AS "Reason",
                               raw_payload AS "Payload"
                        FROM quarantine_records
                        ORDER BY detected_at DESC
                        LIMIT 15;
                        """,
                        conn,
                    )
                st.dataframe(df_quar_raw, use_container_width=True, hide_index=True)
        else:
            st.info("🟢 Zero quarantined payloads. All incoming reports have satisfied schema validation and deduplication constraints.")


# =========================================================================
# TAB 2: Trends & Anomaly Explorer
# =========================================================================
with tab2:
    render_disclaimer_banner()

    col_filter1, col_filter2, col_filter3 = st.columns([2, 2, 2])
    with col_filter1:
        selected_disease = st.selectbox("Surveillance Indicator Disease", DISEASE_NAMES, index=0)
    with col_filter2:
        selected_district = st.selectbox("Surveillance Geographic District", DISTRICTS, index=0)
    with col_filter3:
        time_window = st.selectbox(
            "Temporal Analysis Window",
            ["Last 7 Days (168h)", "Last 14 Days (336h)", "All Recorded History"],
            index=1,
        )

    window_hours = 168 if "7 Days" in time_window else (336 if "14 Days" in time_window else 99999)

    # Query trend data
    with get_connection(DB_PATH) as conn:
        df_trend = pd.read_sql_query(
            """
            SELECT time_bucket, total_cases
            FROM hourly_aggregates
            WHERE disease = ? AND region = ?
            ORDER BY time_bucket DESC
            LIMIT ?;
            """,
            conn,
            params=(selected_disease, selected_district, window_hours),
        )
        # Reverse to chronological order for charts
        df_trend = df_trend.iloc[::-1].reset_index(drop=True)

        # Query anomalies in this series
        df_anomalies = pd.read_sql_query(
            """
            SELECT time_bucket, observed_count, baseline_median, dispersion_scale, score, severity, rationale
            FROM detected_anomalies
            WHERE disease = ? AND region = ?
            ORDER BY time_bucket ASC;
            """,
            conn,
            params=(selected_disease, selected_district),
        )

    if not df_trend.empty:
        # Calculate time-matched baseline & bounds across this series
        df_trend["hour_of_day"] = pd.to_datetime(df_trend["time_bucket"]).dt.hour

        # Group by hour_of_day to get empirical time-matched median and MAD
        baseline_stats = {}
        for h, group in df_trend.groupby("hour_of_day"):
            vals = group["total_cases"].tolist()
            med = float(statistics.median(vals))
            scale, _ = compute_robust_scale(vals, med)
            upper_bound = med + (2.5 * scale)
            baseline_stats[h] = {"median": med, "upper_bound": upper_bound}

        df_trend["baseline_median"] = df_trend["hour_of_day"].map(lambda h: baseline_stats[h]["median"])
        df_trend["upper_bound"] = df_trend["hour_of_day"].map(lambda h: baseline_stats[h]["upper_bound"])

        # Merge anomalies with trend points
        df_merged = pd.merge(
            df_trend,
            df_anomalies[["time_bucket", "score", "severity", "rationale"]],
            on="time_bucket",
            how="left",
        )

        render_section_title(
            f"📈 Epidemiological Trajectory: {selected_disease} in {selected_district}",
            f"Hourly case counts vs. 14-day time-matched median baseline and statistical reference boundary (Z = 2.5)",
        )

        # Build Interactive Plotly Chart
        if HAS_PLOTLY:
            fig = go.Figure()

            # Shaded Expected Variance Corridor (between Median and Upper Bound)
            fig.add_trace(go.Scatter(
                x=df_merged["time_bucket"],
                y=df_merged["upper_bound"],
                mode="lines",
                line=dict(color="rgba(148, 163, 184, 0.4)", width=1, dash="dash"),
                name="Upper Bound (Z = 2.5 Cutoff)",
                hoverinfo="skip",
            ))

            fig.add_trace(go.Scatter(
                x=df_merged["time_bucket"],
                y=df_merged["baseline_median"],
                mode="lines",
                line=dict(color="#64748B", width=1.5, dash="dot"),
                name="Historical Median Baseline",
                fill="tonexty",
                fillcolor="rgba(13, 148, 136, 0.06)",
                hovertemplate="<b>%{x}</b><br>Historical Median: %{y:.1f} cases<extra></extra>",
            ))

            # Observed cases curve
            fig.add_trace(go.Scatter(
                x=df_merged["time_bucket"],
                y=df_merged["total_cases"],
                mode="lines+markers",
                name="Observed Hourly Cases",
                line=dict(color="#0D9488", width=2.5),
                marker=dict(size=4, color="#0D9488"),
                customdata=df_merged[["baseline_median", "upper_bound"]],
                hovertemplate=(
                    "<b>%{x}</b><br>"
                    "Observed: <b>%{y}</b> cases<br>"
                    "Expected Baseline: %{customdata[0]:.1f}<br>"
                    "Upper Bound (Z=2.5): %{customdata[1]:.1f}<extra></extra>"
                ),
            ))

            # Filter detected anomaly points
            anomaly_points = df_merged[df_merged["severity"].notnull() & (df_merged["severity"] != "NORMAL")]
            if not anomaly_points.empty:
                # Color code points based on severity
                sev_colors = anomaly_points["severity"].map({"HIGH": "#DC2626", "MEDIUM": "#D97706", "LOW": "#2563EB"}).fillna("#DC2626")
                fig.add_trace(go.Scatter(
                    x=anomaly_points["time_bucket"],
                    y=anomaly_points["total_cases"],
                    mode="markers",
                    name="Detected Anomalies (Z ≥ 2.5)",
                    marker=dict(
                        symbol="diamond",
                        size=11,
                        color=sev_colors,
                        line=dict(color="#0F172A", width=1.5),
                    ),
                    customdata=anomaly_points[["severity", "score", "baseline_median"]],
                    hovertemplate=(
                        "<b>🔴 STATISTICAL ANOMALY</b><br>"
                        "Timestamp: %{x}<br>"
                        "Observed: <b>%{y} cases</b><br>"
                        "Median Baseline: %{customdata[2]:.1f}<br>"
                        "Deviation Score: <b>Z = %{customdata[1]:.2f}</b><br>"
                        "Severity: %{customdata[0]}<extra></extra>"
                    ),
                ))

            plotly_theme = get_plotly_theme()
            plotly_theme.update(
                title=dict(
                    text=f"Surveillance Series: {selected_disease} — {selected_district}",
                    font=dict(size=15, color="#0F172A"),
                ),
                xaxis=dict(title="Hourly Reporting Bucket (UTC)", showgrid=True, gridcolor="#F1F5F9"),
                yaxis=dict(title="Hourly Case Count", showgrid=True, gridcolor="#F1F5F9"),
                hovermode="x unified",
                height=430,
            )
            fig.update_layout(plotly_theme)
            st.plotly_chart(fig, use_container_width=True)
            st.caption(
                "ℹ️ **Decision Support Guide:** The shaded corridor represents expected normal variance between the 14-day median "
                "and the robust upper reference boundary ($Z = 2.5$). Red and amber diamonds indicate statistically significant departures "
                "flagged for officer investigation."
            )
        else:
            st.line_chart(df_merged.set_index("time_bucket")["total_cases"])

        # Anomaly Evidence Dossier Inspector
        render_section_title("🔍 Statistical Anomaly Evidence Inspector", "Select a flagged observation to inspect its mathematical rationale and dispersion scale")
        if not df_anomalies.empty:
            selected_ano_time = st.selectbox(
                "Select Flagged Anomaly Observation to Inspect",
                df_anomalies["time_bucket"].tolist(),
                index=len(df_anomalies) - 1,
            )
            ano_row = df_anomalies[df_anomalies["time_bucket"] == selected_ano_time].iloc[0]

            # Render evidence dossier card
            render_evidence_dossier(
                observed=float(ano_row["observed_count"]),
                baseline=float(ano_row["baseline_median"]),
                scale=float(ano_row["dispersion_scale"]),
                scale_method="MAD" if ano_row["dispersion_scale"] > 0 else "ZERO_VARIATION_FLOOR",
                score=float(ano_row["score"]),
                severity=str(ano_row["severity"]),
                rationale=str(ano_row["rationale"]),
                time_bucket=str(ano_row["time_bucket"]),
                sample_size=14,
            )
        else:
            st.success(f"🟢 No statistical anomalies detected in this series ({selected_disease} in {selected_district}). Case volume is tracking within expected statistical parameters.")
    else:
        st.warning("No data found for the selected series. Please run simulation steps or seed the database.")


# =========================================================================
# TAB 3: Alert Investigation & Audit Trail
# =========================================================================
with tab3:
    render_disclaimer_banner()

    col_a1, col_a2 = st.columns([2, 2])
    with col_a1:
        status_filter = st.selectbox("Filter by Status", ["All", "PENDING", "ACKNOWLEDGED", "UNDER_INVESTIGATION", "RESOLVED"])
    with col_a2:
        sev_filter = st.selectbox("Filter by Severity", ["All", "HIGH", "MEDIUM"])

    # Query alerts
    with get_connection(DB_PATH) as conn:
        query = "SELECT alert_id, disease, region, severity, status, created_at, updated_at FROM alerts WHERE 1=1"
        params = []
        if status_filter != "All":
            query += " AND status = ?"
            params.append(status_filter)
        if sev_filter != "All":
            query += " AND severity = ?"
            params.append(sev_filter)
        query += " ORDER BY updated_at DESC;"

        df_alerts = pd.read_sql_query(query, conn, params=params)

    st.markdown(f"### 🚨 Health Authority Alert Triage Portal ({len(df_alerts)} alerts)")

    if not df_alerts.empty:
        st.dataframe(
            df_alerts.rename(columns={
                "alert_id": "Alert Tracking ID",
                "disease": "Disease",
                "region": "District",
                "severity": "Severity",
                "status": "Current Status",
                "created_at": "Detection Time",
                "updated_at": "Last Updated",
            }),
            use_container_width=True,
            hide_index=True,
        )

        st.markdown("---")
        st.markdown("### 🛠️ Officer Investigation & Status Transition Form")

        selected_alert_id = st.selectbox(
            "Select Alert to Investigate",
            df_alerts["alert_id"].tolist(),
        )

        selected_alert_row = df_alerts[df_alerts["alert_id"] == selected_alert_id].iloc[0]
        curr_status = selected_alert_row["status"]
        allowed_next = ALLOWED_TRANSITIONS.get(curr_status, set())

        # Check recovery normalization signal
        with get_connection(DB_PATH) as conn:
            recovery_info = check_alert_recovery(
                conn,
                disease=selected_alert_row["disease"],
                region=selected_alert_row["region"],
                current_timestamp=selected_alert_row["updated_at"],
                consecutive_hours=3,
            )

        col_t1, col_t2 = st.columns([3, 2])
        with col_t1:
            st.markdown(f"**Selected Alert:** `{selected_alert_id}` &bull; **Disease:** `{selected_alert_row['disease']}` &bull; **District:** `{selected_alert_row['region']}`")
            st.markdown(f"**Current Status:** `{curr_status}` &bull; **Severity:** `{selected_alert_row['severity']}`")

            if recovery_info["is_recovered"]:
                st.success(f"🟢 **Normalization Indicator:** {recovery_info['explanation']}")
            else:
                st.warning(f"🟠 **Surveillance Status:** {recovery_info['explanation']}")

            if allowed_next:
                new_status = st.radio("Select New Status Transition:", sorted(list(allowed_next)), horizontal=True)
                officer_name = st.text_input("Officer Name / Identifier", value="District Health Officer")
                officer_notes = st.text_area("Investigation & Field Action Notes", placeholder="e.g. Reviewed 14-day trend curve; dispatched local vector control inspection.")

                if st.button("💾 Submit Status Update & Record Audit Event", use_container_width=True):
                    if not officer_notes.strip():
                        st.error("Please provide investigation notes for this action before submitting.")
                    else:
                        with get_db(DB_PATH) as conn:
                            update_alert_status(
                                conn=conn,
                                alert_id=selected_alert_id,
                                new_status=new_status,
                                officer_notes=officer_notes,
                                officer_name=officer_name,
                            )
                        st.success(f"Alert {selected_alert_id} updated to {new_status} with audit log entry.")
                        st.rerun()
            else:
                st.info("This alert is in a terminal state (RESOLVED) and cannot undergo further status transitions.")

        with col_t2:
            st.markdown("#### 📜 Chronological Audit History")
            with get_connection(DB_PATH) as conn:
                history = get_alert_history(conn, selected_alert_id)
            if history:
                df_history = pd.DataFrame(history)[["action", "previous_status", "new_status", "officer_notes", "timestamp"]]
                st.dataframe(df_history.rename(columns={
                    "action": "Action",
                    "previous_status": "From",
                    "new_status": "To",
                    "officer_notes": "Logged Notes",
                    "timestamp": "Timestamp",
                }), use_container_width=True, hide_index=True)
            else:
                st.caption("No audit history found for this alert.")
    else:
        st.success("🟢 No alerts match the current filter criteria.")


# =========================================================================
# TAB 4: Outbreak Demonstration & Mock Notifications
# =========================================================================
with tab4:
    render_disclaimer_banner()

    st.markdown("### 💥 One-Click Outbreak Anomaly Injector (Viva Demonstration)")
    st.markdown(
        "Use this control during project evaluation to inject a controlled, statistically significant surge "
        "and immediately verify real-time detection, alert creation, and local mock-email dispatch."
    )

    col_inj1, col_inj2, col_inj3 = st.columns(3)
    with col_inj1:
        inj_disease = st.selectbox("Target Condition", DISEASE_NAMES, index=0, key="inj_dis")
    with col_inj2:
        inj_district = st.selectbox("Target District", DISTRICTS, index=0, key="inj_dist")
    with col_inj3:
        inj_multiplier = st.slider("Surge Multiplier", min_value=2.0, max_value=8.0, value=4.5, step=0.5, help="Multiplier applied to expected baseline rate")

    if st.button("🚨 Inject Controlled Outbreak Surge for Current Hour", type="primary", use_container_width=True):
        with get_connection(DB_PATH) as conn:
            cur = conn.cursor()
            cur.execute("SELECT MAX(timestamp) AS latest_ts FROM raw_records;")
            latest_ts = cur.fetchone()["latest_ts"]

        if latest_ts:
            clean_ts = latest_ts.replace("Z", "+00:00")
            current_dt = datetime.fromisoformat(clean_ts)
        else:
            current_dt = datetime.now(timezone.utc)

        # Baseline expectation
        meta = DISEASES[inj_disease]
        base_lambda = meta["base_lambda"]
        surge_cases = max(18, int(round(base_lambda * inj_multiplier * 1.3)))

        # Generate unique report
        report = generate_single_report(
            timestamp=current_dt,
            region=inj_district,
            disease=inj_disease,
            case_count=surge_cases,
        )

        with get_db(DB_PATH) as conn:
            # 1. Ingest
            ing_res = ingest_record(conn, report, reference_now=current_dt)

            # 2. Detect
            ano_res = detect_and_record_anomaly(
                conn=conn,
                current_count=surge_cases,
                time_bucket=report["timestamp"],
                disease=inj_disease,
                region=inj_district,
                persist=True,
            )

            # 3. Alert & Mock Email
            alert_res = process_anomaly_for_alert(conn, ano_res)

        st.success(
            f"✅ Injected {surge_cases} cases of {inj_disease} in {inj_district} for {report['timestamp']}. "
            f"Detected: {ano_res['severity']} priority anomaly (Z = {ano_res['score']:.2f}). "
            f"Alert Status: {alert_res['status']} ({alert_res.get('alert_id', 'N/A')})."
        )
        st.rerun()

    st.markdown("---")

    # Local Mock Email Viewer
    st.markdown("### 📬 Local Mock-Email Notifications Inbox")
    st.markdown(
        "All generated alert briefs are rendered as HTML and stored on the local filesystem. "
        "No external networks or email servers are ever contacted."
    )

    mock_files = sorted(list(MOCK_EMAIL_DIR.glob("*.html")), key=lambda p: p.stat().st_mtime, reverse=True)

    if mock_files:
        col_m1, col_m2 = st.columns([2, 3])
        with col_m1:
            selected_file = st.selectbox(
                "Select Saved Mock Email Brief to Preview",
                mock_files,
                format_func=lambda p: f"{p.name} ({p.stat().st_size} bytes)",
            )
            if selected_file:
                html_text = selected_file.read_text(encoding="utf-8")
                st.download_button(
                    "📥 Download HTML Brief",
                    data=html_text,
                    file_name=selected_file.name,
                    mime="text/html",
                    use_container_width=True,
                )

        with col_m2:
            if selected_file:
                st.markdown("#### 📄 In-Dashboard HTML Email Preview")
                st.components.v1.html(html_text, height=520, scrolling=True)
    else:
        st.info("No mock email briefs have been generated yet. Inject an outbreak above or step the simulation.")

    st.markdown("---")

    # CSV Data Export
    st.markdown("### 💾 Export Synthetic Surveillance Records")
    st.markdown("Download surveillance datasets with embedded synthetic demonstration disclaimers.")

    col_exp1, col_exp2 = st.columns(2)
    with col_exp1:
        with get_connection(DB_PATH) as conn:
            df_export_agg = pd.read_sql_query("SELECT * FROM hourly_aggregates ORDER BY time_bucket DESC LIMIT 1000;", conn)
        csv_agg = f"# {SYNTHETIC_DATA_DISCLAIMER}\n" + df_export_agg.to_csv(index=False)
        st.download_button(
            "📥 Download Hourly Aggregates (CSV)",
            data=csv_agg,
            file_name="synthetic_hourly_aggregates.csv",
            mime="text/csv",
            use_container_width=True,
        )

    with col_exp2:
        with get_connection(DB_PATH) as conn:
            df_export_alerts = pd.read_sql_query("SELECT * FROM alerts ORDER BY updated_at DESC;", conn)
        csv_alerts = f"# {SYNTHETIC_DATA_DISCLAIMER}\n" + df_export_alerts.to_csv(index=False)
        st.download_button(
            "📥 Download Alerts & Investigations (CSV)",
            data=csv_alerts,
            file_name="synthetic_surveillance_alerts.csv",
            mime="text/csv",
            use_container_width=True,
        )
