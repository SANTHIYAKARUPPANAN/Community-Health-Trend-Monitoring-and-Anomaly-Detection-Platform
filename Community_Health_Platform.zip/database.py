"""
Database Module for Community Health Trend Monitoring & Anomaly Detection Platform.
Handles SQLite connection lifecycle, WAL mode configuration, DDL schema creation,
and deterministic 14-day synthetic baseline data seeding (reconciled to 6,720 records).
"""

from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
import math
from pathlib import Path
import random
import sqlite3
from typing import Any, Dict, Generator, List, Optional
import uuid

from config import (
    BASELINE_START_TIME,
    DB_PATH,
    DISEASE_NAMES,
    DISEASES,
    DISTRICT_FACILITIES,
    DISTRICTS,
    RANDOM_SEED,
    TOTAL_EXPECTED_SEED_RECORDS,
    TOTAL_SEED_HOURS,
)

# -------------------------------------------------------------------------
# Connection Management
# -------------------------------------------------------------------------
def get_connection(
    db_path: Optional[Path] = None, wal_mode: bool = True
) -> sqlite3.Connection:
    """
    Creates and configures an SQLite database connection.
    Enforces foreign keys, row factory for dict-like access, and WAL journal mode.
    """
    target_path = Path(db_path) if db_path else DB_PATH
    if target_path != Path(":memory:"):
        target_path.parent.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(
        str(target_path),
        timeout=10.0,
        detect_types=sqlite3.PARSE_DECLTYPES,
    )
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")

    # In-memory databases do not support or need WAL mode
    if wal_mode and str(target_path) != ":memory:":
        conn.execute("PRAGMA journal_mode = WAL;")

    return conn


@contextmanager
def get_db(db_path: Optional[Path] = None) -> Generator[sqlite3.Connection, None, None]:
    """
    Context manager providing atomic transactional SQLite connection.
    Commits on clean exit, rolls back on exception, and ensures connection closure.
    """
    conn = get_connection(db_path)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# -------------------------------------------------------------------------
# Schema DDL Definitions
# -------------------------------------------------------------------------
SCHEMA_DDL = """
-- 1. Raw clinic reports (Enforces Client Nonce Deduplication)
CREATE TABLE IF NOT EXISTS raw_records (
    record_id TEXT PRIMARY KEY,
    client_submission_id TEXT NOT NULL UNIQUE,
    timestamp TEXT NOT NULL,
    facility_id TEXT NOT NULL,
    region TEXT NOT NULL,
    disease TEXT NOT NULL,
    case_count INTEGER NOT NULL CHECK (case_count >= 0),
    is_synthetic INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
);

-- 2. Quarantined malformed or duplicate records
CREATE TABLE IF NOT EXISTS quarantine_records (
    quarantine_id INTEGER PRIMARY KEY AUTOINCREMENT,
    raw_payload TEXT NOT NULL,
    rejection_reason TEXT NOT NULL,
    detected_at TEXT NOT NULL
);

-- 3. Hourly aggregates for trend analysis and anomaly detection
CREATE TABLE IF NOT EXISTS hourly_aggregates (
    aggregate_id TEXT PRIMARY KEY,
    time_bucket TEXT NOT NULL,
    disease TEXT NOT NULL,
    region TEXT NOT NULL,
    total_cases INTEGER NOT NULL CHECK (total_cases >= 0),
    report_count INTEGER NOT NULL CHECK (report_count >= 0),
    rolling_median_14d REAL,
    rolling_mad_14d REAL,
    UNIQUE(time_bucket, disease, region)
);

-- 4. Anomaly detection records
CREATE TABLE IF NOT EXISTS detected_anomalies (
    anomaly_id INTEGER PRIMARY KEY AUTOINCREMENT,
    time_bucket TEXT NOT NULL,
    disease TEXT NOT NULL,
    region TEXT NOT NULL,
    observed_count INTEGER NOT NULL,
    baseline_median REAL NOT NULL,
    dispersion_scale REAL NOT NULL,
    score REAL NOT NULL,
    severity TEXT NOT NULL CHECK (severity IN ('LOW', 'MEDIUM', 'HIGH')),
    rationale TEXT NOT NULL,
    detected_at TEXT NOT NULL
);

-- 5. Alert lifecycle state table
CREATE TABLE IF NOT EXISTS alerts (
    alert_id TEXT PRIMARY KEY,
    anomaly_id INTEGER NOT NULL REFERENCES detected_anomalies(anomaly_id),
    disease TEXT NOT NULL,
    region TEXT NOT NULL,
    severity TEXT NOT NULL CHECK (severity IN ('LOW', 'MEDIUM', 'HIGH')),
    status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'ACKNOWLEDGED', 'UNDER_INVESTIGATION', 'RESOLVED')),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

-- 6. Immutable audit log of all officer actions & system events
CREATE TABLE IF NOT EXISTS alert_audit_logs (
    audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
    alert_id TEXT NOT NULL REFERENCES alerts(alert_id),
    action TEXT NOT NULL,
    previous_status TEXT,
    new_status TEXT,
    officer_notes TEXT,
    timestamp TEXT NOT NULL
);

-- 7. Local mock notification records
CREATE TABLE IF NOT EXISTS mock_notifications (
    notification_id INTEGER PRIMARY KEY AUTOINCREMENT,
    alert_id TEXT NOT NULL REFERENCES alerts(alert_id),
    recipient TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('MOCK_SAVED', 'MOCK_FAILED')),
    file_path TEXT NOT NULL,
    sent_at TEXT NOT NULL
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_raw_records_timestamp ON raw_records(timestamp);
CREATE INDEX IF NOT EXISTS idx_raw_records_disease_region ON raw_records(disease, region);
CREATE INDEX IF NOT EXISTS idx_hourly_agg_disease_region ON hourly_aggregates(disease, region, time_bucket);
CREATE INDEX IF NOT EXISTS idx_anomalies_timestamp ON detected_anomalies(time_bucket);
CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status, severity);
"""


def init_db(db_path: Optional[Path] = None) -> None:
    """
    Initializes all database tables and indexes if they do not already exist.
    """
    with get_db(db_path) as conn:
        conn.executescript(SCHEMA_DDL)


# -------------------------------------------------------------------------
# Poisson Sampling Helper (Dependency-Free & Deterministic)
# -------------------------------------------------------------------------
def _sample_poisson(lam: float, rng: random.Random) -> int:
    """
    Generates a Poisson sample using Knuth's algorithm.
    Deterministic when driven by a seeded random.Random instance.
    """
    if lam <= 0:
        return 0
    # Knuth algorithm for small-to-moderate lambda
    limit = math.exp(-lam)
    k = 0
    p = 1.0
    while p > limit:
        k += 1
        p *= rng.random()
    return max(0, k - 1)


# -------------------------------------------------------------------------
# Deterministic Baseline Seeder (Reconciles to exactly 6,720 records)
# -------------------------------------------------------------------------
def seed_historical_baseline(
    db_path: Optional[Path] = None,
    seed: int = RANDOM_SEED,
    force: bool = False,
) -> Dict[str, Any]:
    """
    Seeds exactly 14 days of hourly synthetic baseline records for 5 districts and 4 diseases.
    Reconciles exactly to 6,720 raw records and 6,720 hourly aggregate records.

    Data Dimensions:
      5 districts * 4 diseases = 20 series
      14 days * 24 hours = 336 hours
      20 series * 336 hours = 6,720 observations

    Guarantees:
      - Deterministic (fixed seed)
      - Labeled synthetic (is_synthetic = 1)
      - Non-negative case counts
      - Pre-populates hourly_aggregates so anomaly detector has immediate baseline
    """
    init_db(db_path)

    with get_db(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) AS cnt FROM raw_records;")
        existing_count = cursor.fetchone()["cnt"]

        if existing_count > 0 and not force:
            cursor.execute("SELECT MIN(timestamp) AS min_t, MAX(timestamp) AS max_t FROM raw_records;")
            span = cursor.fetchone()
            return {
                "status": "ALREADY_SEEDED",
                "raw_records_count": existing_count,
                "start_time": span["min_t"],
                "end_time": span["max_t"],
                "reconciled": (existing_count == TOTAL_EXPECTED_SEED_RECORDS),
            }

        if force:
            cursor.execute("DELETE FROM mock_notifications;")
            cursor.execute("DELETE FROM alert_audit_logs;")
            cursor.execute("DELETE FROM alerts;")
            cursor.execute("DELETE FROM detected_anomalies;")
            cursor.execute("DELETE FROM hourly_aggregates;")
            cursor.execute("DELETE FROM quarantine_records;")
            cursor.execute("DELETE FROM raw_records;")

        rng = random.Random(seed)
        namespace = uuid.NAMESPACE_OID

        raw_records_batch: List[tuple] = []
        aggregates_batch: List[tuple] = []

        now_str = datetime.now(timezone.utc).isoformat()

        # Day of week weight multiplier (lower clinic volumes on weekend, Monday catch-up)
        # Monday=0 -> 1.15, Tue-Fri=1..4 -> 1.0, Sat=5 -> 0.85, Sun=6 -> 0.75
        weekday_weights = {0: 1.15, 1: 1.0, 2: 1.0, 3: 1.0, 4: 1.0, 5: 0.85, 6: 0.75}

        for h_idx in range(TOTAL_SEED_HOURS):
            current_dt = BASELINE_START_TIME + timedelta(hours=h_idx)
            time_bucket = current_dt.strftime("%Y-%m-%dT%H:00:00Z")
            hour_of_day = current_dt.hour
            weekday = current_dt.weekday()
            w_factor = weekday_weights.get(weekday, 1.0)

            for region, facility in DISTRICT_FACILITIES.items():
                for disease, meta in DISEASES.items():
                    peak = meta["peak_hour"]
                    base_lambda = meta["base_lambda"]

                    # Diurnal curve calculation (smooth bell curve around peak hour)
                    dist = abs(hour_of_day - peak)
                    dist = min(dist, 24 - dist)
                    diurnal_factor = 0.45 + 0.85 * math.exp(-(dist**2) / 18.0)

                    expected_lambda = base_lambda * diurnal_factor * w_factor
                    case_count = _sample_poisson(expected_lambda, rng)

                    # Deterministic UUIDv5 strings
                    record_id = str(uuid.uuid5(namespace, f"rec_seed_{h_idx:04d}_{region}_{disease}"))
                    client_sub_id = str(uuid.uuid5(namespace, f"sub_seed_{h_idx:04d}_{region}_{disease}"))

                    raw_records_batch.append((
                        record_id,
                        client_sub_id,
                        time_bucket,
                        facility,
                        region,
                        disease,
                        case_count,
                        1,  # is_synthetic = 1
                        now_str,
                    ))

                    aggregate_id = f"{time_bucket}_{disease}_{region}"
                    aggregates_batch.append((
                        aggregate_id,
                        time_bucket,
                        disease,
                        region,
                        case_count,
                        1,  # report_count = 1
                    ))

        # Insert all batches atomically
        cursor.executemany("""
            INSERT INTO raw_records (
                record_id, client_submission_id, timestamp, facility_id,
                region, disease, case_count, is_synthetic, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
        """, raw_records_batch)

        cursor.executemany("""
            INSERT INTO hourly_aggregates (
                aggregate_id, time_bucket, disease, region, total_cases, report_count
            ) VALUES (?, ?, ?, ?, ?, ?);
        """, aggregates_batch)

        # Verification & Reconciliation
        cursor.execute("SELECT COUNT(*) AS cnt FROM raw_records;")
        final_raw_count = cursor.fetchone()["cnt"]

        cursor.execute("SELECT COUNT(*) AS cnt FROM hourly_aggregates;")
        final_agg_count = cursor.fetchone()["cnt"]

        cursor.execute("SELECT MIN(timestamp) AS min_t, MAX(timestamp) AS max_t FROM raw_records;")
        time_span = cursor.fetchone()

        cursor.execute("SELECT COUNT(DISTINCT timestamp) AS distinct_hours FROM raw_records;")
        distinct_hours = cursor.fetchone()["distinct_hours"]

        cursor.execute("SELECT SUM(case_count) AS total_cases FROM raw_records;")
        total_cases = cursor.fetchone()["total_cases"]

    return {
        "status": "SUCCESS",
        "raw_records_count": final_raw_count,
        "hourly_aggregates_count": final_agg_count,
        "expected_count": TOTAL_EXPECTED_SEED_RECORDS,
        "reconciled": (final_raw_count == TOTAL_EXPECTED_SEED_RECORDS == final_agg_count),
        "distinct_hours": distinct_hours,
        "expected_hours": TOTAL_SEED_HOURS,
        "start_time": time_span["min_t"],
        "end_time": time_span["max_t"],
        "total_cases_seeded": total_cases,
        "regions_seeded": len(DISTRICTS),
        "diseases_seeded": len(DISEASE_NAMES),
    }


def get_table_counts(conn: sqlite3.Connection) -> Dict[str, int]:
    """
    Returns row counts for all database tables.
    Works with both sqlite3.Row and standard tuple connections.
    """
    tables = [
        "raw_records",
        "quarantine_records",
        "hourly_aggregates",
        "detected_anomalies",
        "alerts",
        "alert_audit_logs",
        "mock_notifications",
    ]
    counts = {}
    for table in tables:
        cur = conn.execute(f"SELECT COUNT(*) AS cnt FROM {table};")
        row = cur.fetchone()
        counts[table] = row["cnt"] if hasattr(row, "keys") else row[0]
    return counts


if __name__ == "__main__":
    print("=" * 70)
    print("Community Health Platform — Database Initialization & Baseline Seeding")
    print("=" * 70)
    print(f"Target DB: {DB_PATH}")
    init_db()
    stats = seed_historical_baseline(force=True)
    print(f"Status: {stats['status']}")
    print(f"Raw Records Seeded: {stats['raw_records_count']:,} (Expected: {stats['expected_count']:,})")
    print(f"Hourly Aggregates Seeded: {stats['hourly_aggregates_count']:,}")
    print(f"Reconciled: {stats['reconciled']}")
    print(f"Time Range: {stats['start_time']} -> {stats['end_time']} ({stats['distinct_hours']} hours)")
    print(f"Total Cases: {stats['total_cases_seeded']:,}")
    print("=" * 70)

