"""
Unit tests for Milestone 2: Data ingestion, validation, quarantine, deduplication, and aggregation.
Tests all requirements including negative cases, malformed timestamps, future clock skew,
duplicate re-transmission idempotency, supplementary reports, and atomic rollback.
"""

from datetime import datetime, timedelta, timezone
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config import (
    BASELINE_START_TIME,
    DISTRICT_FACILITIES,
    DISTRICTS,
)
from database import get_connection, get_db, init_db, seed_historical_baseline
from pipeline import (
    ingest_batch,
    ingest_record,
    log_quarantine,
    validate_record,
)
from simulator import (
    generate_duplicate_retransmission,
    generate_single_report,
    generate_supplementary_report,
    simulate_hour_tick,
)


class TestPipelineIngestionAndValidation(unittest.TestCase):
    """Tests for record validation, quarantine logging, and schema constraints."""

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_pipeline.db"
        init_db(self.db_path)
        self.reference_time = datetime(2026, 10, 23, 14, 0, 0, tzinfo=timezone.utc)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_valid_record_ingestion(self):
        """Verifies that a valid report ingests and updates raw_records and hourly_aggregates."""
        record = generate_single_report(
            timestamp=self.reference_time,
            region="Central Metro",
            disease="Dengue",
            case_count=8,
            client_submission_id="test-sub-001",
        )

        with get_db(self.db_path) as conn:
            result = ingest_record(conn, record, reference_now=self.reference_time)

            self.assertEqual(result["status"], "INGESTED")
            self.assertEqual(result["cases_added"], 8)

            # Check raw_records
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) AS cnt FROM raw_records WHERE client_submission_id = 'test-sub-001';")
            self.assertEqual(cur.fetchone()["cnt"], 1)

            # Check hourly_aggregates
            agg_id = f"{record['timestamp']}_Dengue_Central Metro"
            cur.execute("SELECT total_cases, report_count FROM hourly_aggregates WHERE aggregate_id = ?;", (agg_id,))
            agg = cur.fetchone()
            self.assertIsNotNone(agg)
            self.assertEqual(agg["total_cases"], 8)
            self.assertEqual(agg["report_count"], 1)

    def test_negative_case_counts_quarantined(self):
        """Verifies that negative case counts are rejected to quarantine and do not touch aggregates."""
        record = generate_single_report(
            timestamp=self.reference_time,
            region="Central Metro",
            disease="Dengue",
            case_count=-4,
            client_submission_id="test-neg-cases",
        )

        with get_db(self.db_path) as conn:
            result = ingest_record(conn, record, reference_now=self.reference_time)

            self.assertEqual(result["status"], "QUARANTINED")
            self.assertIn("NEGATIVE_CASE_COUNT", result["reason"])

            # Verify quarantine_records entry
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) AS cnt, rejection_reason FROM quarantine_records;")
            q = cur.fetchone()
            self.assertEqual(q["cnt"], 1)
            self.assertIn("NEGATIVE_CASE_COUNT", q["rejection_reason"])

            # Verify neither raw_records nor hourly_aggregates was touched
            cur.execute("SELECT COUNT(*) AS cnt FROM raw_records WHERE client_submission_id = 'test-neg-cases';")
            self.assertEqual(cur.fetchone()["cnt"], 0)
            cur.execute("SELECT COUNT(*) AS cnt FROM hourly_aggregates;")
            self.assertEqual(cur.fetchone()["cnt"], 0)

    def test_malformed_timestamp_quarantined(self):
        """Verifies that malformed date strings are rejected with explicit reason."""
        record = generate_single_report(
            timestamp=self.reference_time,
            region="Central Metro",
            disease="Dengue",
            case_count=5,
            client_submission_id="test-bad-date",
        )
        record["timestamp"] = "not-a-valid-date-string"

        with get_db(self.db_path) as conn:
            result = ingest_record(conn, record, reference_now=self.reference_time)

            self.assertEqual(result["status"], "QUARANTINED")
            self.assertIn("MALFORMED_TIMESTAMP", result["reason"])

            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) AS cnt FROM quarantine_records WHERE rejection_reason LIKE '%MALFORMED_TIMESTAMP%';")
            self.assertEqual(cur.fetchone()["cnt"], 1)

    def test_missing_required_fields_quarantined(self):
        """Verifies that records missing required fields are quarantined."""
        bad_record = {
            "record_id": "REC-INCOMPLETE",
            "client_submission_id": "sub-incomplete",
            # missing timestamp, facility_id, region, disease, case_count
        }

        with get_db(self.db_path) as conn:
            result = ingest_record(conn, bad_record, reference_now=self.reference_time)
            self.assertEqual(result["status"], "QUARANTINED")
            self.assertIn("MISSING_REQUIRED_FIELDS", result["reason"])

    def test_future_timestamp_policy(self):
        """Verifies that timestamps exceeding surveillance clock tolerance are quarantined."""
        # 1. 2 hours into the future beyond 15-minute tolerance -> REJECT
        future_time = self.reference_time + timedelta(hours=2)
        future_record = generate_single_report(
            timestamp=future_time,
            region="North Valley",
            disease="Influenza",
            case_count=6,
            client_submission_id="test-future",
        )

        with get_db(self.db_path) as conn:
            res_future = ingest_record(
                conn, future_record, reference_now=self.reference_time, max_future_minutes=15
            )
            self.assertEqual(res_future["status"], "QUARANTINED")
            self.assertIn("FUTURE_TIMESTAMP", res_future["reason"])

        # 2. 5 minutes into the future within 15-minute skew tolerance -> ACCEPT
        tolerable_time = self.reference_time + timedelta(minutes=5)
        tolerable_record = generate_single_report(
            timestamp=tolerable_time,
            region="North Valley",
            disease="Influenza",
            case_count=6,
            client_submission_id="test-tolerable",
        )

        with get_db(self.db_path) as conn:
            res_tol = ingest_record(
                conn, tolerable_record, reference_now=self.reference_time, max_future_minutes=15
            )
            self.assertEqual(res_tol["status"], "INGESTED")

    def test_unsupported_district_or_facility_mismatch_quarantined(self):
        """Verifies that unrecognized districts or mismatched facilities are quarantined."""
        # Unrecognized region
        rec_bad_region = generate_single_report(
            timestamp=self.reference_time,
            region="Unknown Atlantis District",
            disease="Dengue",
            case_count=3,
            client_submission_id="test-unknown-reg",
        )
        with get_db(self.db_path) as conn:
            res = ingest_record(conn, rec_bad_region, reference_now=self.reference_time)
            self.assertEqual(res["status"], "QUARANTINED")
            self.assertIn("INVALID_REGION", res["reason"])

        # Facility mismatched with district
        rec_mismatch = generate_single_report(
            timestamp=self.reference_time,
            region="Central Metro",
            disease="Dengue",
            case_count=3,
            facility="North Community Clinic",  # Registered in North Valley, not Central Metro
            client_submission_id="test-mismatch-fac",
        )
        with get_db(self.db_path) as conn:
            res = ingest_record(conn, rec_mismatch, reference_now=self.reference_time)
            self.assertEqual(res["status"], "QUARANTINED")
            self.assertIn("MISMATCHED_FACILITY", res["reason"])


class TestDeduplicationAndAggregation(unittest.TestCase):
    """Tests for idempotent retransmission, supplementary reports, and aggregate mathematics."""

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_dedup.db"
        init_db(self.db_path)
        self.reference_time = datetime(2026, 10, 23, 14, 0, 0, tzinfo=timezone.utc)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_duplicate_submission_idempotency(self):
        """
        Verifies that re-transmitting the exact same client_submission_id
        is safely rejected and NEVER increments total_cases or report_count twice.
        """
        original = generate_single_report(
            timestamp=self.reference_time,
            region="Central Metro",
            disease="Dengue",
            case_count=10,
            client_submission_id="unique-nonce-999",
        )

        with get_db(self.db_path) as conn:
            # 1. First ingestion -> Ingested successfully
            res1 = ingest_record(conn, original, reference_now=self.reference_time)
            self.assertEqual(res1["status"], "INGESTED")

            # Check initial aggregate values
            agg_id = f"{original['timestamp']}_Dengue_Central Metro"
            cur = conn.cursor()
            cur.execute("SELECT total_cases, report_count FROM hourly_aggregates WHERE aggregate_id = ?;", (agg_id,))
            agg1 = cur.fetchone()
            self.assertEqual(agg1["total_cases"], 10)
            self.assertEqual(agg1["report_count"], 1)

            # 2. Duplicate retransmission clone (network retry)
            clone = generate_duplicate_retransmission(original)
            res2 = ingest_record(conn, clone, reference_now=self.reference_time)
            self.assertEqual(res2["status"], "DUPLICATE_REJECTED")

            # Check aggregate values after retransmission -> MUST BE UNCHANGED
            cur.execute("SELECT total_cases, report_count FROM hourly_aggregates WHERE aggregate_id = ?;", (agg_id,))
            agg2 = cur.fetchone()
            self.assertEqual(agg2["total_cases"], 10, "Total cases must NOT be incremented by duplicate retransmission!")
            self.assertEqual(agg2["report_count"], 1, "Report count must NOT be incremented by duplicate retransmission!")

            # Verify quarantine log recorded duplicate retransmission
            cur.execute("SELECT COUNT(*) AS cnt FROM quarantine_records WHERE rejection_reason LIKE '%DUPLICATE_CLIENT_SUBMISSION_ID%';")
            self.assertEqual(cur.fetchone()["cnt"], 1)

    def test_legitimate_supplementary_reports_are_aggregated(self):
        """
        Verifies that legitimate supplementary reports (same time bucket, facility, disease,
        and region, but with distinct client_submission_id) are accepted and summed correctly.
        """
        initial_report = generate_single_report(
            timestamp=self.reference_time,
            region="Central Metro",
            disease="Dengue",
            case_count=10,
            client_submission_id="batch-morning-triage",
        )

        # Supplementary report from afternoon clinic annex
        supplementary_report = generate_supplementary_report(initial_report, additional_cases=7)

        with get_db(self.db_path) as conn:
            # Ingest initial report (10 cases)
            res1 = ingest_record(conn, initial_report, reference_now=self.reference_time)
            self.assertEqual(res1["status"], "INGESTED")

            # Ingest supplementary report (7 cases)
            res2 = ingest_record(conn, supplementary_report, reference_now=self.reference_time)
            self.assertEqual(res2["status"], "INGESTED")

            # Verify both raw records exist
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) AS cnt FROM raw_records;")
            self.assertEqual(cur.fetchone()["cnt"], 2)

            # Verify hourly_aggregates combined total: 10 + 7 = 17, report_count = 2
            agg_id = f"{initial_report['timestamp']}_Dengue_Central Metro"
            cur.execute("SELECT total_cases, report_count FROM hourly_aggregates WHERE aggregate_id = ?;", (agg_id,))
            agg = cur.fetchone()
            self.assertEqual(agg["total_cases"], 17)
            self.assertEqual(agg["report_count"], 2)

    def test_atomic_batch_rollback_on_failure(self):
        """
        Verifies that if an unhandled database failure occurs, the entire batch
        is rolled back atomically without leaving partial state.
        """
        valid_rec1 = generate_single_report(
            timestamp=self.reference_time,
            region="Central Metro",
            disease="Dengue",
            case_count=5,
            client_submission_id="batch-item-1",
        )
        valid_rec2 = generate_single_report(
            timestamp=self.reference_time,
            region="North Valley",
            disease="Influenza",
            case_count=4,
            client_submission_id="batch-item-2",
        )

        conn = get_connection(self.db_path)
        try:
            # Manually simulate an error during batch execution by locking or injecting bad statement
            with self.assertRaises(sqlite3.OperationalError):
                with conn:
                    ingest_record(conn, valid_rec1, reference_now=self.reference_time)
                    # Trigger deliberate SQL syntax error to test transaction rollback
                    conn.execute("INVALID SQL STATEMENT THAT MUST TRIGGER ROLLBACK;")
                    ingest_record(conn, valid_rec2, reference_now=self.reference_time)
        finally:
            conn.close()

        # Reopen connection and assert database remains completely empty (rolled back)
        with get_db(self.db_path) as verify_conn:
            cur = verify_conn.cursor()
            cur.execute("SELECT COUNT(*) AS cnt FROM raw_records;")
            self.assertEqual(cur.fetchone()["cnt"], 0, "All inserts must have rolled back on error!")
            cur.execute("SELECT COUNT(*) AS cnt FROM hourly_aggregates;")
            self.assertEqual(cur.fetchone()["cnt"], 0, "Aggregates must have rolled back on error!")


class TestSimulationStepProgression(unittest.TestCase):
    """Tests synchronous deterministic simulation step progression."""

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_sim_step.db"
        seed_historical_baseline(self.db_path, seed=42, force=True)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_simulation_hour_tick_advances_clock(self):
        """
        Verifies that simulate_hour_tick advances the simulation clock by +1 hour,
        emits 20 records (5 districts * 4 diseases), and ingests them into the database.
        """
        # Baseline ends at 2026-10-22T23:00:00Z
        # Step 1 should advance to 2026-10-23T00:00:00Z
        tick_res = simulate_hour_tick(self.db_path, seed=123)

        self.assertEqual(tick_res["status"], "SUCCESS")
        self.assertEqual(tick_res["tick_time"], "2026-10-23T00:00:00Z")
        self.assertEqual(tick_res["records_generated"], 20)
        self.assertEqual(tick_res["ingested"], 20)
        self.assertEqual(tick_res["duplicate_rejected"], 0)
        self.assertEqual(tick_res["quarantined"], 0)

        # Check total raw records: 6,720 + 20 = 6,740
        with get_db(self.db_path) as conn:
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) AS cnt FROM raw_records;")
            self.assertEqual(cur.fetchone()["cnt"], 6740)

            cur.execute("SELECT COUNT(*) AS cnt FROM hourly_aggregates;")
            self.assertEqual(cur.fetchone()["cnt"], 6740)

        # Step 2 should advance to 2026-10-23T01:00:00Z
        tick_res_2 = simulate_hour_tick(self.db_path, seed=124)
        self.assertEqual(tick_res_2["tick_time"], "2026-10-23T01:00:00Z")
        self.assertEqual(tick_res_2["ingested"], 20)

        with get_db(self.db_path) as conn:
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) AS cnt FROM raw_records;")
            self.assertEqual(cur.fetchone()["cnt"], 6760)

    def test_pipeline_persistence_across_reconnect(self):
        """Verifies that newly ingested simulation records and quarantine logs persist after reconnect."""
        simulate_hour_tick(self.db_path, seed=123)

        # Log a quarantine record to verify persistence
        with get_db(self.db_path) as conn:
            log_quarantine(conn, {"dummy": "corrupt"}, "TEST_PERSISTENCE_REASON")

        # Explicitly close and reopen new connection
        conn2 = get_connection(self.db_path)
        try:
            cur = conn2.cursor()
            cur.execute("SELECT COUNT(*) AS cnt FROM raw_records;")
            self.assertEqual(cur.fetchone()["cnt"], 6740)

            cur.execute("SELECT COUNT(*) AS cnt FROM quarantine_records WHERE rejection_reason = 'TEST_PERSISTENCE_REASON';")
            self.assertEqual(cur.fetchone()["cnt"], 1)
        finally:
            conn2.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
