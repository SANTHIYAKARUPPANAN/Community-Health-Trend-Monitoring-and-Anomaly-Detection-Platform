"""
Unit tests for Milestone 1: Database module, schema constraints, and deterministic seeder.
Compatible with standard python unittest and pytest runners.
"""

from datetime import datetime, timezone
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest

# Ensure project root is in python path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config import (
    BASELINE_START_TIME,
    DISEASES,
    DISTRICT_FACILITIES,
    DISTRICTS,
    TOTAL_EXPECTED_SEED_RECORDS,
    TOTAL_SEED_HOURS,
)
from database import (
    get_connection,
    get_db,
    get_table_counts,
    init_db,
    seed_historical_baseline,
)


class TestDatabaseFoundation(unittest.TestCase):
    """Tests schema creation, integrity constraints, and connection lifecycle."""

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_surveillance.db"

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_schema_initialization(self):
        """Verifies that all 7 required tables are created with proper schemas."""
        init_db(self.db_path)
        with get_db(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';"
            )
            tables = {row["name"] for row in cursor.fetchall()}

        expected_tables = {
            "raw_records",
            "quarantine_records",
            "hourly_aggregates",
            "detected_anomalies",
            "alerts",
            "alert_audit_logs",
            "mock_notifications",
        }
        self.assertTrue(expected_tables.issubset(tables), f"Missing tables: {expected_tables - tables}")

    def test_client_submission_id_unique_constraint(self):
        """Verifies that duplicate client_submission_id triggers an IntegrityError."""
        init_db(self.db_path)
        with get_db(self.db_path) as conn:
            conn.execute(
                """
                INSERT INTO raw_records (
                    record_id, client_submission_id, timestamp, facility_id,
                    region, disease, case_count, is_synthetic, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?);
                """,
                ("rec-001", "sub-nonce-123", "2026-10-23T14:00:00Z", "Central District Hospital",
                 "Central Metro", "Dengue", 5, "2026-10-23T14:05:00Z"),
            )

            # Inserting the exact same client_submission_id must fail
            with self.assertRaises(sqlite3.IntegrityError):
                conn.execute(
                    """
                    INSERT INTO raw_records (
                        record_id, client_submission_id, timestamp, facility_id,
                        region, disease, case_count, is_synthetic, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?);
                    """,
                    ("rec-002", "sub-nonce-123", "2026-10-23T14:00:00Z", "Central District Hospital",
                     "Central Metro", "Dengue", 5, "2026-10-23T14:06:00Z"),
                )

    def test_negative_case_count_check_constraint(self):
        """Verifies that negative case counts are prevented by CHECK constraint."""
        init_db(self.db_path)
        with get_db(self.db_path) as conn:
            with self.assertRaises(sqlite3.IntegrityError):
                conn.execute(
                    """
                    INSERT INTO raw_records (
                        record_id, client_submission_id, timestamp, facility_id,
                        region, disease, case_count, is_synthetic, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?);
                    """,
                    ("rec-neg", "sub-neg", "2026-10-23T14:00:00Z", "Central District Hospital",
                     "Central Metro", "Dengue", -3, "2026-10-23T14:05:00Z"),
                )

    def test_hourly_aggregate_unique_constraint(self):
        """Verifies that (time_bucket, disease, region) must be unique in hourly_aggregates."""
        init_db(self.db_path)
        with get_db(self.db_path) as conn:
            conn.execute(
                """
                INSERT INTO hourly_aggregates (
                    aggregate_id, time_bucket, disease, region, total_cases, report_count
                ) VALUES (?, ?, ?, ?, ?, ?);
                """,
                ("agg-1", "2026-10-23T14:00:00Z", "Dengue", "Central Metro", 10, 1),
            )

            with self.assertRaises(sqlite3.IntegrityError):
                conn.execute(
                    """
                    INSERT INTO hourly_aggregates (
                        aggregate_id, time_bucket, disease, region, total_cases, report_count
                    ) VALUES (?, ?, ?, ?, ?, ?);
                    """,
                    ("agg-2", "2026-10-23T14:00:00Z", "Dengue", "Central Metro", 5, 1),
                )


class TestBaselineSeeder(unittest.TestCase):
    """Tests deterministic baseline data generation and reconciliation."""

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "seed_test.db"

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_seeder_record_count_reconciliation(self):
        """Verifies that exactly 6,720 raw records and 6,720 hourly aggregates are seeded."""
        result = seed_historical_baseline(self.db_path, force=True)

        self.assertEqual(result["status"], "SUCCESS")
        self.assertEqual(result["raw_records_count"], TOTAL_EXPECTED_SEED_RECORDS)
        self.assertEqual(result["hourly_aggregates_count"], TOTAL_EXPECTED_SEED_RECORDS)
        self.assertEqual(result["raw_records_count"], 6720)
        self.assertTrue(result["reconciled"])

    def test_seeder_time_coverage_and_continuity(self):
        """Verifies that timestamps cover exactly 336 contiguous hours without gaps."""
        seed_historical_baseline(self.db_path, force=True)

        with get_db(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(DISTINCT timestamp) AS distinct_hours FROM raw_records;")
            distinct_hours = cursor.fetchone()["distinct_hours"]

            cursor.execute("SELECT MIN(timestamp) AS min_t, MAX(timestamp) AS max_t FROM raw_records;")
            time_span = cursor.fetchone()

        self.assertEqual(distinct_hours, TOTAL_SEED_HOURS)
        self.assertEqual(distinct_hours, 336)

        # Expected start: 2026-10-09T00:00:00Z
        # Expected end (hour 335): 2026-10-22T23:00:00Z
        self.assertEqual(time_span["min_t"], "2026-10-09T00:00:00Z")
        self.assertEqual(time_span["max_t"], "2026-10-22T23:00:00Z")

    def test_seeder_synthetic_label_and_non_negative_cases(self):
        """Verifies that 100% of records are labeled synthetic and have non-negative cases."""
        seed_historical_baseline(self.db_path, force=True)

        with get_db(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) AS non_synthetic FROM raw_records WHERE is_synthetic != 1;")
            self.assertEqual(cursor.fetchone()["non_synthetic"], 0)

            cursor.execute("SELECT COUNT(*) AS negative_cases FROM raw_records WHERE case_count < 0;")
            self.assertEqual(cursor.fetchone()["negative_cases"], 0)

    def test_seeder_deterministic_reproducibility(self):
        """Verifies that seeding twice with seed=42 produces bit-for-bit identical sums."""
        db_path_2 = Path(self.temp_dir.name) / "seed_test_2.db"

        res1 = seed_historical_baseline(self.db_path, seed=42, force=True)
        res2 = seed_historical_baseline(db_path_2, seed=42, force=True)

        self.assertEqual(res1["total_cases_seeded"], res2["total_cases_seeded"])

        with get_db(self.db_path) as conn1, get_db(db_path_2) as conn2:
            rows1 = conn1.execute(
                "SELECT record_id, timestamp, disease, region, case_count FROM raw_records ORDER BY timestamp, region, disease LIMIT 50;"
            ).fetchall()
            rows2 = conn2.execute(
                "SELECT record_id, timestamp, disease, region, case_count FROM raw_records ORDER BY timestamp, region, disease LIMIT 50;"
            ).fetchall()

            for r1, r2 in zip(rows1, rows2):
                self.assertEqual(dict(r1), dict(r2))

    def test_persistence_after_connection_reopen(self):
        """Verifies that seeded data and table structures persist after closing and reopening connection."""
        seed_historical_baseline(self.db_path, force=True)

        # Explicitly close and reopen a brand new connection
        conn = get_connection(self.db_path)
        try:
            counts = get_table_counts(conn)
            self.assertEqual(counts["raw_records"], 6720)
            self.assertEqual(counts["hourly_aggregates"], 6720)
            self.assertEqual(counts["quarantine_records"], 0)
            self.assertEqual(counts["alerts"], 0)
        finally:
            conn.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
