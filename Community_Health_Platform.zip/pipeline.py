"""
Pipeline Module for Community Health Trend Monitoring & Anomaly Detection Platform.
Handles schema validation, quarantine management, deterministic deduplication,
and atomic hourly temporal-spatial aggregation.
"""

from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3
from typing import Any, Dict, List, Optional, Tuple

from config import (
    DISEASE_NAMES,
    DISEASES,
    DISTRICT_FACILITIES,
    DISTRICTS,
)

# -------------------------------------------------------------------------
# Required Fields & Validation Constants
# -------------------------------------------------------------------------
REQUIRED_FIELDS = {
    "record_id",
    "client_submission_id",
    "timestamp",
    "facility_id",
    "region",
    "disease",
    "case_count",
}

# Maximum allowed future clock drift for incoming records (in minutes)
DEFAULT_MAX_FUTURE_MINUTES = 15


# -------------------------------------------------------------------------
# Record Validation Logic
# -------------------------------------------------------------------------
def validate_record(
    record: Dict[str, Any],
    reference_now: Optional[datetime] = None,
    max_future_minutes: int = DEFAULT_MAX_FUTURE_MINUTES,
) -> Tuple[bool, Optional[str], Optional[Dict[str, Any]]]:
    """
    Validates an incoming clinic report against platform constraints.

    Validation Rules:
      1. All required fields must be present and non-null.
      2. Region must match one of the 5 configured surveillance districts.
      3. Facility must match the registered facility for that region.
      4. Disease must match one of the 4 configured indicator conditions.
      5. Case count must be a non-negative integer (not boolean, float, or string).
      6. Timestamp must be a valid ISO-8601 string.
      7. Future timestamp policy: Timestamps cannot exceed the surveillance clock
         plus a maximum tolerance (default 15 minutes clock skew).

    Returns:
      (is_valid, rejection_reason, normalized_record)
    """
    if not isinstance(record, dict):
        return False, "INVALID_PAYLOAD_STRUCTURE: Payload must be a JSON object / dict", None

    # 1. Required Fields Check
    missing = [f for f in REQUIRED_FIELDS if f not in record or record[f] is None]
    if missing:
        return False, f"MISSING_REQUIRED_FIELDS: Missing {', '.join(sorted(missing))}", None

    record_id = str(record["record_id"]).strip()
    client_sub_id = str(record["client_submission_id"]).strip()
    if not record_id or not client_sub_id:
        return False, "EMPTY_IDENTIFIER: record_id and client_submission_id must not be empty", None

    # 2. Region Validation
    region = str(record["region"]).strip()
    if region not in DISTRICTS:
        return False, f"INVALID_REGION: '{region}' is not a recognized surveillance district", None

    # 3. Facility Validation
    facility = str(record["facility_id"]).strip()
    expected_facility = DISTRICT_FACILITIES.get(region)
    if facility != expected_facility:
        return (
            False,
            f"MISMATCHED_FACILITY: Facility '{facility}' is not registered for district '{region}' (expected '{expected_facility}')",
            None,
        )

    # 4. Disease Validation
    disease = str(record["disease"]).strip()
    if disease not in DISEASE_NAMES:
        return False, f"INVALID_DISEASE: '{disease}' is not a recognized surveillance indicator disease", None

    # 5. Case Count Validation (Must be true non-negative integer, not boolean)
    cases = record["case_count"]
    if isinstance(cases, bool) or not isinstance(cases, int):
        return False, f"INVALID_CASE_COUNT_TYPE: case_count '{cases}' must be an integer", None
    if cases < 0:
        return False, f"NEGATIVE_CASE_COUNT: case_count '{cases}' cannot be negative", None

    # 6. Timestamp Validation (ISO-8601)
    raw_ts = str(record["timestamp"]).strip()
    try:
        # Standard ISO-8601 parsing; replace Z with +00:00 for fromisoformat compatibility
        clean_ts = raw_ts.replace("Z", "+00:00")
        parsed_dt = datetime.fromisoformat(clean_ts)
        if parsed_dt.tzinfo is None:
            parsed_dt = parsed_dt.replace(tzinfo=timezone.utc)
        else:
            parsed_dt = parsed_dt.astimezone(timezone.utc)
    except Exception:
        return False, f"MALFORMED_TIMESTAMP: '{raw_ts}' is not a valid ISO-8601 timestamp string", None

    # 7. Future Timestamp Policy
    clock = reference_now if reference_now is not None else datetime.now(timezone.utc)
    if clock.tzinfo is None:
        clock = clock.replace(tzinfo=timezone.utc)

    diff_seconds = (parsed_dt - clock).total_seconds()
    max_allowed_seconds = max_future_minutes * 60
    if diff_seconds > max_allowed_seconds:
        return (
            False,
            f"FUTURE_TIMESTAMP: Timestamp '{raw_ts}' is {diff_seconds / 60:.1f} minutes ahead of surveillance clock (tolerance: {max_future_minutes} min)",
            None,
        )

    # Normalized fields
    time_bucket = parsed_dt.strftime("%Y-%m-%dT%H:00:00Z")
    aggregate_id = f"{time_bucket}_{disease}_{region}"

    normalized = {
        "record_id": record_id,
        "client_submission_id": client_sub_id,
        "timestamp": time_bucket,
        "facility_id": facility,
        "region": region,
        "disease": disease,
        "case_count": cases,
        "aggregate_id": aggregate_id,
        "time_bucket": time_bucket,
        "is_synthetic": 1,
    }
    return True, None, normalized


# -------------------------------------------------------------------------
# Quarantine Storage Helper
# -------------------------------------------------------------------------
def log_quarantine(
    conn: sqlite3.Connection,
    raw_payload: Any,
    rejection_reason: str,
    detected_at: Optional[datetime] = None,
) -> int:
    """
    Persists an invalid or duplicate record into quarantine_records.
    Guarantees that corrupt records never pollute downstream aggregates.
    """
    ts = detected_at if detected_at is not None else datetime.now(timezone.utc)
    ts_str = ts.isoformat()

    try:
        payload_str = json.dumps(raw_payload) if not isinstance(raw_payload, str) else raw_payload
    except Exception:
        payload_str = str(raw_payload)

    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT INTO quarantine_records (raw_payload, rejection_reason, detected_at)
        VALUES (?, ?, ?);
        """,
        (payload_str, rejection_reason, ts_str),
    )
    return cursor.lastrowid


# -------------------------------------------------------------------------
# Ingestion & Atomic Aggregation
# -------------------------------------------------------------------------
def ingest_record(
    conn: sqlite3.Connection,
    raw_record: Dict[str, Any],
    reference_now: Optional[datetime] = None,
    max_future_minutes: int = DEFAULT_MAX_FUTURE_MINUTES,
) -> Dict[str, Any]:
    """
    Atomically validates, ingests, and aggregates a single report.

    Lifecycle:
      1. Schema & business rule validation -> Quarantine on failure.
      2. Check for duplicate client_submission_id -> Quarantine on duplicate (idempotent retransmission).
      3. Insert into raw_records.
      4. Increment hourly_aggregates (total_cases += cases, report_count += 1).
      All database changes are atomic within the caller's transaction.
    """
    is_valid, reason, normalized = validate_record(
        raw_record, reference_now=reference_now, max_future_minutes=max_future_minutes
    )

    if not is_valid:
        qid = log_quarantine(conn, raw_record, reason)
        return {
            "status": "QUARANTINED",
            "quarantine_id": qid,
            "reason": reason,
        }

    now_str = datetime.now(timezone.utc).isoformat()

    # Attempt raw_records insert with strict UNIQUE(client_submission_id)
    try:
        conn.execute(
            """
            INSERT INTO raw_records (
                record_id, client_submission_id, timestamp, facility_id,
                region, disease, case_count, is_synthetic, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
            """,
            (
                normalized["record_id"],
                normalized["client_submission_id"],
                normalized["timestamp"],
                normalized["facility_id"],
                normalized["region"],
                normalized["disease"],
                normalized["case_count"],
                1,
                now_str,
            ),
        )
    except sqlite3.IntegrityError as e:
        dup_reason = (
            f"DUPLICATE_CLIENT_SUBMISSION_ID: '{normalized['client_submission_id']}' "
            f"has already been ingested. Retransmission safely ignored."
        )
        qid = log_quarantine(conn, raw_record, dup_reason)
        return {
            "status": "DUPLICATE_REJECTED",
            "quarantine_id": qid,
            "reason": dup_reason,
            "client_submission_id": normalized["client_submission_id"],
        }

    # Atomically update hourly_aggregates
    conn.execute(
        """
        INSERT INTO hourly_aggregates (
            aggregate_id, time_bucket, disease, region, total_cases, report_count
        ) VALUES (?, ?, ?, ?, ?, 1)
        ON CONFLICT(aggregate_id) DO UPDATE SET
            total_cases = total_cases + excluded.total_cases,
            report_count = report_count + 1;
        """,
        (
            normalized["aggregate_id"],
            normalized["time_bucket"],
            normalized["disease"],
            normalized["region"],
            normalized["case_count"],
        ),
    )

    return {
        "status": "INGESTED",
        "record_id": normalized["record_id"],
        "aggregate_id": normalized["aggregate_id"],
        "time_bucket": normalized["time_bucket"],
        "cases_added": normalized["case_count"],
        "disease": normalized["disease"],
        "region": normalized["region"],
    }


def ingest_batch(
    conn: sqlite3.Connection,
    records: List[Dict[str, Any]],
    reference_now: Optional[datetime] = None,
    max_future_minutes: int = DEFAULT_MAX_FUTURE_MINUTES,
) -> Dict[str, Any]:
    """
    Ingests a batch of records inside a single transaction.
    If an unexpected database-level exception occurs, the entire batch is rolled back.
    """
    ingested_count = 0
    duplicate_count = 0
    quarantine_count = 0
    results = []

    # Use a savepoint/transaction block to guarantee atomicity
    with conn:
        for rec in records:
            res = ingest_record(
                conn, rec, reference_now=reference_now, max_future_minutes=max_future_minutes
            )
            results.append(res)
            if res["status"] == "INGESTED":
                ingested_count += 1
            elif res["status"] == "DUPLICATE_REJECTED":
                duplicate_count += 1
            else:
                quarantine_count += 1

    return {
        "total_records": len(records),
        "ingested": ingested_count,
        "duplicate_rejected": duplicate_count,
        "quarantined": quarantine_count,
        "results": results,
    }
